# Combined multiple PB[etc] scripts into one.
# Ordered as follows:
# PBStatuses
# PBStats
# PBWeather
# PBEnvironment
# PBEffects
# PBNatures
class PBStatuses
  SLEEP     = 1
  POISON    = 2
  BURN      = 3
  PARALYSIS = 4
  FROZEN    = 5
  FAINTED   = 6
  POKERUS   = 7
end

class PBStats
  HP       = 0
  ATTACK   = 1
  DEFENSE  = 2
  SPATK    = 3
  SPDEF    = 4
  SPEED    = 5
  ACCURACY = 6
  EVASION  = 7
end

module PBNatures
  HARDY   = 0
  LONELY  = 1
  ADAMANT = 2
  NAUGHTY = 3
  BRAVE   = 4
  DOCILE  = 6
  BOLD    = 5
  IMPISH  = 7 
  LAX     = 8
  RELAXED = 9
  BASHFUL = 10 
  MODEST  = 11 
  QUIET   = 12
  RASH    = 13
  MILD    = 14
  QUIRKY  = 15 
  CALM    = 16
  SASSY   = 17 
  CAREFUL = 18  
  GENTLE  = 19 
  SERIOUS = 20 
  TIMID   = 21
  HASTY   = 22
  JOLLY   = 23
  NAIVE   = 24

  def PBNatures.maxValue; 24; end
  def PBNatures.getCount; 25; end

  def PBNatures.getName(id)
    names=[
      _INTL("Hardy"),
      _INTL("Lonely"),
      _INTL("Brave"),
      _INTL("Adamant"),
      _INTL("Naughty"),
      _INTL("Docile"), # docile <-> bold
      _INTL("Bold"),
      _INTL("Relaxed"),
      _INTL("Impish"),
      _INTL("Lax"),
      _INTL("Serious"), # serious -> timid, timid -> hasty, hasty -> serious
      _INTL("Timid"),
      _INTL("Hasty"),
      _INTL("Jolly"),
      _INTL("Naive"),
      _INTL("Bashful"), # bashful -> modest, modest -> mild, mild -> quiet, quiet -> modest
      _INTL("Modest"),
      _INTL("Mild"),
      _INTL("Quiet"),
      _INTL("Rash"),
      _INTL("Quirky"), # quirky -> calm, calm -> gentle, gentle -> sassy, sassy -> careful, careful -> quirky 
      _INTL("Calm"),
      _INTL("Gentle"),
      _INTL("Sassy"),
      _INTL("Careful")
    ]
    return names[id]
  end

  def PBNatures.getNameAndStatString(id) # LAWDS - used for macho brace
    name_stat_string=[
      _INTL("Neutral"),
      _INTL("(+Atk  -Def)"),
      _INTL("(+Atk  -Spe)"),
      _INTL("(+Atk  -SpA)"),
      _INTL("(+Atk  -SpD)"),
      _INTL("Neutral 2"), # docile <-> bold
      _INTL("(+Def  -Atk)"),
      _INTL("(+Def  -Spe)"),
      _INTL("(+Def  -SpA)"),
      _INTL("(+Def  -SpD)"),
      _INTL("Neutral 3"), # serious -> timid, timid -> hasty, hasty -> serious
      _INTL("(+Spe  -Atk)"),
      _INTL("(+Spe  -Def)"),
      _INTL("(+Spe  -SpA)"),
      _INTL("(+Spe  -SpD)"),
      _INTL("Neutral 4"), # bashful -> modest, modest -> mild, mild -> quiet, quiet -> modest
      _INTL("(+SpA  -Atk)"),
      _INTL("(+SpA  -Def)"),
      _INTL("(+SpA  -Spe)"),
      _INTL("(+SpA  -SpD)"),
      _INTL("Neutral 5"), # quirky -> calm, calm -> gentle, gentle -> sassy, sassy -> careful, careful -> quirky 
      _INTL("(+SpD  -Atk)"),
      _INTL("(+SpD  -Def)"),
      _INTL("(+SpD  -Spe)"),
      _INTL("(+SpD  -SpA)")
   ]
   return name_stat_string[id]
  end
end