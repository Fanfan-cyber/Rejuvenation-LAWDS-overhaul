 
class PokeBattle_Scene
 def pbWaitMessage
    if @briefmessage
      pbShowWindow(MESSAGEBOX)
      cw=@sprites["messagewindow"]
      5.times do
        pbGraphicsUpdate
        Input.update
      end
      cw.text=""
      cw.visible=false
      @briefmessage=false
    end
  end
  
    def pbSendOut(battlerindex, pkmn) # Player sending out Pokémon
    while inPartyAnimation?; end
    balltype = pkmn.ballused
    ballbitmap = sprintf("Graphics/Pictures/Battle/%s", balltype)
    pictureBall = PictureEx.new(32)
    delay = 1
    pictureBall.moveVisible(delay, true)
    pictureBall.moveName(delay, ballbitmap)
    pictureBall.moveOrigin(delay, PictureOrigin::Center)
    # Setting the ball's movement path
    path = [[124, 216], [127, 238]]
    spriteBall = IconSprite.new(0, 0, @viewport)
    spriteBall.visible = false
    angle = 0
    multiplier = 1.0
    if @battle.doublebattle
      multiplier = (battlerindex == 0) ? 0.7 : 1.3
    end
    for coord in path
      delay = pictureBall.totalDuration
      pictureBall.moveAngle(0, delay, angle)
      pictureBall.moveXY(1, delay, coord[0] * multiplier, coord[1])
      angle += 40
      angle %= 360
    end
    pictureBall.adjustPosition(0, @traineryoffset)
    @sprites["battlebox#{battlerindex}"].visible = false
    @briefmessage = false
    fadeanim = nil
    if @showingplayer
      fadeanim = PlayerFadeAnimation.new(@sprites)
    end
    frame = 0
    @sprites["pokemon#{battlerindex}"].setPokemonBitmap(pkmn, true)
    if @battle.battlers[battlerindex].effects[:Illusion] != nil
      @sprites["pokemon#{battlerindex}"].setPokemonBitmap(
        @battle.battlers[battlerindex].effects[:Illusion].pokemon, true
      )
    end
    sendout = PokeballPlayerSendOutAnimation.new(
      @sprites["pokemon#{battlerindex}"],
      @sprites, @battle.battlers[battlerindex], @battle.doublebattle,
      @battle.battlers[battlerindex].effects[:Illusion], @battle
    )
    @sprites["pokemon#{battlerindex}"].opacity = 255
    loop do
      fadeanim.update if fadeanim
      frame += 1
      if frame > 1 && !pictureBall.running? && !@sprites["battlebox#{battlerindex}"].appearing
        @sprites["battlebox#{battlerindex}"].appear
      end
      if frame >= 3 && !pictureBall.running?
        sendout.update
      end
      if (frame >= 10 || !fadeanim) && pictureBall.running?
        pictureBall.update
        setPictureIconSprite(spriteBall, pictureBall)
      end
      @sprites["battlebox#{battlerindex}"].update
      pbGraphicsUpdate
      Input.update
      break if (!fadeanim || fadeanim.animdone?) && sendout.animdone? &&
               !@sprites["battlebox#{battlerindex}"].appearing
    end
    spriteBall.dispose
    sendout.dispose
    if @battle.battlescene && ((@battle.battlers[battlerindex].pokemon.isShiny? &&
      @battle.battlers[battlerindex].effects[:Illusion].nil?) ||
       (@battle.battlers[battlerindex].effects[:Illusion] != nil &&
       @battle.battlers[battlerindex].effects[:Illusion].pokemon.isShiny?))
      pbCommonAnimation("Shiny", @battle.battlers[battlerindex], nil)
    end
    if @showingplayer
      @showingplayer = false
      pbDisposeSprite(@sprites, "player")
      pbDisposeSprite(@sprites, "partybarplayer")
      for i in 0...6
        pbDisposeSprite(@sprites, "player#{i}")
      end
    end
    if @battle.battlers[battlerindex].effects[:Substitute] > 0
      move = PokeBattle_Move.pbFromPBMove(@battle, PBMove.new(:SUBSTITUTE), @battle.battlers[battlerindex])
      @battle.battlers[battlerindex].effects[:UsingSubstituteRightNow] = true
      # move.pbShowAnimation(:SUBSTITUTE,@battle.battlers[battlerindex],nil)
      @battle.scene.pbAnimation(move, @battle.battlers[battlerindex], nil)
      @battle.battlers[battlerindex].effects[:UsingSubstituteRightNow] = false
    end
    @battle.seedCheck if @battle.turncount != 0
    pbRefresh
  end
  
    def pbRecall(battlerindex)
    @briefmessage = false
    if @battle.pbIsOpposing?(battlerindex)
      origin = PBScene::FOEBATTLER_Y
      if @battle.doublebattle
        origin = PBScene::FOEBATTLERD1_Y if battlerindex == 1
        origin = PBScene::FOEBATTLERD2_Y if battlerindex == 3
      end
      @sprites["shadow#{battlerindex}"].visible = false
    else
      origin = PBScene::PLAYERBATTLER_Y
      if @battle.doublebattle
        origin = PBScene::PLAYERBATTLERD1_Y if battlerindex == 0
        origin = PBScene::PLAYERBATTLERD2_Y if battlerindex == 2
      end
    end
    spritePoke = @sprites["pokemon#{battlerindex}"]
    picturePoke = PictureEx.new(spritePoke.z)
    center = getSpriteCenter(spritePoke)
    # starting positions
    picturePoke.moveVisible(1, true)
    picturePoke.moveOrigin(1, PictureOrigin::Center)
    picturePoke.moveXY(0, 1, center[0], center[1])
    # directives
    #    picturePoke.moveTone(10,1,Tone.new(0,-224,-224,0))
    picturePoke.moveTone(10, 1, Tone.new(248, 248, 248, 248))
    delay = 1
    picturePoke.moveSE(delay, "Audio/SE/recall")
    picturePoke.moveZoom(15, 1, 0)
    picturePoke.moveXY(15, 1, center[0], origin)
    picturePoke.moveVisible(1, false)
    picturePoke.moveTone(0, 1, Tone.new(0, 0, 0, 0))
    picturePoke.moveOrigin(1, PictureOrigin::TopLeft)
    loop do
      picturePoke.update
      setPictureSprite(spritePoke, picturePoke)
      pbGraphicsUpdate
      Input.update
      break if !picturePoke.running?
    end
  end
  
    def pbDisplayMessage(msg,brief=false)
    # Display old message
    pbWaitMessage
    pbRefresh
    pbShowWindow(MESSAGEBOX)

    # Set new message
    cw=@sprites["messagewindow"]
    cw.text=msg
    i=0
    loop do
      pbGraphicsUpdate
      Input.update
      cw.update
      if i==10
        cw.text=""
        cw.visible=false
        return
      end
      if Input.trigger?(Input::C)
        if cw.pausing?
          pbPlayDecisionSE()
          cw.resume
        end
      end
      if !cw.busy?
        if brief
          @briefmessage=true
          5.times do
            pbGraphicsUpdate
            Input.update
          end
          return
        end
        i+=1
      end
    end
  end
  
    def pbDisplayPausedMessage(msg)
    pbWaitMessage
    pbRefresh
    pbShowWindow(MESSAGEBOX)
    if @messagemode
      @switchscreen.pbDisplay(msg)
      return
    end
    cw=@sprites["messagewindow"]
    cw.text=_ISPRINTF("{1:s}\1",msg)
    loop do
      pbGraphicsUpdate
      Input.update
      if Input.trigger?(Input::C)
        if cw.busy?
          pbPlayDecisionSE() if cw.pausing?
          cw.resume
        elsif !inPartyAnimation?
          cw.text=""
          pbPlayDecisionSE()
          cw.visible=false if @messagemode
          return
        end
      end
      cw.update
    end
  end
  
  
    def pbDamageAnimation(pkmn,effectiveness)
    pkmnsprite=@sprites["pokemon#{pkmn.index}"]
    shadowsprite=@sprites["shadow#{pkmn.index}"]
    sprite=@sprites["battlebox#{pkmn.index}"]
    oldshadowvisible=shadowsprite.visible
    oldvisible=sprite.visible
    sprite.selected=2
    @briefmessage=false
    3.times do
      pbGraphicsUpdate
      Input.update
    end
    case effectiveness
    when 0
      @battle.pbIsOpposing?(pkmn.index) ? pbSEPlay("normaldamage") : pbSEPlay("normaldamage_L")
    when 1
      @battle.pbIsOpposing?(pkmn.index) ? pbSEPlay("notverydamage") : pbSEPlay("notverydamage_L")
    when 2
      @battle.pbIsOpposing?(pkmn.index) ? pbSEPlay("superdamage") : pbSEPlay("superdamage_L")
  end
    4.times do
      pkmnsprite.visible=!pkmnsprite.visible
      if oldshadowvisible
        shadowsprite.visible=!shadowsprite.visible
      end
      2.times do
        pbGraphicsUpdate
        Input.update
        sprite.update
      end
    end
    sprite.selected=0
    sprite.visible=oldvisible
  end
  
 end
  
  class PBAnimationPlayerX
    def update
    return if @frame<0
    if (@frame>>1) >= @animation.length
      @frame=(@looping) ? 0 : -1
      if @frame<0
        unless (@user).nil?
          unless defined?(@user.effects).nil?
            if @user.effects[:UsingSubstituteRightNow]==true
              @scene.pbSubstituteSprite(@user,@user.pbIsOpposing?(1))
            end
          end        
        end        
        @animbitmap.dispose if @animbitmap
        @animbitmap=nil
        return
      end
    end
    if !@animbitmap || @animbitmap.disposed?
      @animbitmap=AnimatedBitmap.new("Graphics/Animations/"+@animation.graphic,
         @animation.hue).deanimate
      @animsprites[0]=@usersprite if @animsprites[0]
      @animsprites[1]=@targetsprite if @animsprites[1] #These might be redundant idk
      for i in 2...MAXSPRITES
        @animsprites[i].bitmap=@animbitmap if @animsprites[i]
      end
    end
    @bgGraphic.update
    @bgColor.update
    @foGraphic.update
    @foColor.update
    if (@frame&1)==0
      thisframe=@animation[@frame>>1]
      # Make all cel sprites invisible
      for i in 0...MAXSPRITES
        @animsprites[i].visible=false if @animsprites[i]
      end
      # Set each cel sprite acoordingly
      for i in 0...thisframe.length
        cel=thisframe[i]
        next if !cel
        framecheck = 1
        while cel == 0
          cel = @animation[(@frame>>1)-framecheck][i]
          framecheck += 3
        end
        sprite=@animsprites[i]
        next if !sprite
        # Set cel sprite's graphic
        if cel[AnimFrame::PATTERN]==-1
          sprite.bitmap=@userbitmap
        elsif cel[AnimFrame::PATTERN]==-2
          sprite.bitmap=@targetbitmap
        else
          sprite.bitmap=@animbitmap
        end
        # Apply settings to the cel sprite
        pbSpriteSetAnimFrame(sprite,cel,@usersprite,@targetsprite)
        if ((@user && @user==@target) || @targetSwitch==true) && @animation.name!="Move:TACKLE" && @animation.name!="Move:DOOMDUMMY" && @animation.name!="Move:FUTUREDUMMY" #fixing user/target refs for user target moves. Tackle excluded because default move animation used in some places (e.g. seed recharge) and dummy moves excluded since they turn self target if original user is taken out. Might be worth either adding something to move or animation data to check here instead when we rework this?
          selftarget=true
          if @user.index==0 || @user.index==2 #on player side
            @dstLine[2]=@userOrig[0]+256
            @dstLine[3]=@userOrig[1]-128
          else
            @dstLine[2]=@userOrig[0]-256
            @dstLine[3]=@userOrig[1]+128
          end
        end
        case cel[AnimFrame::FOCUS]
          when 1   # Focused on target
            sprite.x=cel[AnimFrame::X]+@targetOrig[0]-PBScene::FOCUSTARGET_X
            sprite.y=cel[AnimFrame::Y]+@targetOrig[1]-PBScene::FOCUSTARGET_Y
            if (@movedata && @movedata.target==:OpposingSide) && (@partnerbs||@allmonbs) && i>1
              sprite.x=@centerboth[2]+(cel[AnimFrame::X]-PBScene::FOCUSTARGET_X)
              sprite.y=@centerboth[3]+(cel[AnimFrame::Y]-PBScene::FOCUSTARGET_Y)
            end
          when 2   # Focused on user
            sprite.x=cel[AnimFrame::X]+@userOrig[0]-PBScene::FOCUSUSER_X
            sprite.y=cel[AnimFrame::Y]+@userOrig[1]-PBScene::FOCUSUSER_Y
            if (@movedata && @movedata.target==:OpposingSide) && (@partnerbs||@allmonbs) && i>1
              sprite.x=@centerboth[2]+(cel[AnimFrame::X]-PBScene::FOCUSUSER_X)
              sprite.y=@centerboth[3]+(cel[AnimFrame::Y]-PBScene::FOCUSUSER_Y)
            end
          when 3   # Focused on user and target
            if @srcLine && @dstLine
              if @partnerbs && cel[AnimFrame::PATTERN]!=-2 && cel[AnimFrame::PATTERN]!=-1
                point=transformPoint(
                  @srcLine[0],@srcLine[1],@srcLine[2],@srcLine[3],
                  @centerboth[0],@centerboth[1],@centerboth[2],@centerboth[3],
                  sprite.x,sprite.y)
                sprite.x=point[0]
                sprite.y=point[1]
                if isReversed(@srcLine[0],@srcLine[2],@centerboth[0],@centerboth[2]) && cel[AnimFrame::PATTERN]>=0 && @animation.oppflip != false
                  # Reverse direction
                  sprite.mirror=!sprite.mirror
                end

              elsif selftarget==true && i<=1
                point=transformPoint(
                  @srcLine[0],@srcLine[1],@srcLine[2],@srcLine[3],
                  @dstLine[0],@dstLine[1],@dstLine[4],@dstLine[5],
                  sprite.x,sprite.y)
                sprite.x=point[0]
                sprite.y=point[1]
                if isReversed(@srcLine[0],@srcLine[2],@dstLine[0],@dstLine[4]) && cel[AnimFrame::PATTERN]>=0 &&  @animation.oppflip != false
                  # Reverse direction
                  sprite.mirror=!sprite.mirror
                end
                
              else
                point=transformPoint(
                  @srcLine[0],@srcLine[1],@srcLine[2],@srcLine[3],
                  @dstLine[0],@dstLine[1],@dstLine[2],@dstLine[3],
                  sprite.x,sprite.y)
                sprite.x=point[0]
                sprite.y=point[1]
                if isReversed(@srcLine[0],@srcLine[2],@dstLine[0],@dstLine[2]) && cel[AnimFrame::PATTERN]>=0 &&  @animation.oppflip != false
                  # Reverse direction
                  sprite.mirror=!sprite.mirror
                end
              end
            end
        end
        sprite.x+=64 if @ineditor
        sprite.y+=64 if @ineditor
      end
      #Add bullshit for making both targets move if doubles 
      if @partnerbs
        ptargetbullshit=@realtarget.index #Adding this to the arson list
        ptargetbullshit+=1 if ((@realtarget.index==0 || @realtarget.index==2) && !@isOppMove)
        ptargetbullshit-=1 if ((@realtarget.index==1 || @realtarget.index==3) && @isOppMove)
        cel = thisframe[ptargetbullshit-2] if ptargetbullshit>1
        cel = thisframe[ptargetbullshit] if ptargetbullshit<2 #cel of target
        pbSpriteSetAnimFrame(@animpartner,cel,@usersprite,@animpartner)
        case cel[AnimFrame::FOCUS]
          when 1   # Focused on target
            if ptargetbullshit==1 || ptargetbullshit-2==1
              @animpartner.x=cel[AnimFrame::X]+@partnerOrig[0]-PBScene::FOCUSTARGET_X
              @animpartner.y=cel[AnimFrame::Y]+@partnerOrig[1]-PBScene::FOCUSTARGET_Y
            else
              @animpartner.x=cel[AnimFrame::X]+@userOrig[0]-PBScene::FOCUSTARGET_X
              @animpartner.y=cel[AnimFrame::Y]+@userOrig[1]-PBScene::FOCUSTARGET_Y
            end   
            when 2   # Focused on user
              if ptargetbullshit==1 || ptargetbullshit-2==1
                @animpartner.x=cel[AnimFrame::X]+@userOrig[0]-PBScene::FOCUSUSER_X
                @animpartner.y=cel[AnimFrame::Y]+@userOrig[1]-PBScene::FOCUSUSER_Y
              else
                @animpartner.x=cel[AnimFrame::X]+@partnerOrig[0]-PBScene::FOCUSUSER_X
                @animpartner.y=cel[AnimFrame::Y]+@partnerOrig[1]-PBScene::FOCUSUSER_Y
              end
            when 3   # Focused on user and target
              point=transformPoint(
                @partnerline[0],@partnerline[1],@partnerline[2],@partnerline[3],
                @partnerline[4],@partnerline[5],@partnerline[6],@partnerline[7],
                @animpartner.x,@animpartner.y)
              @animpartner.x=point[0]
              @animpartner.y=point[1]
              if isReversed(@partnerline[0],@partnerline[2],@partnerline[4],@partnerline[6]) &&
                cel[AnimFrame::PATTERN]>=0 && @animation.oppflip != false
                # Reverse direction
                @animpartner.mirror=!@animpartner.mirror
              end
        end
      end
      #More bullshit but for all target moves
      if @allmonbs
        targetbullshit=@realtarget.index #Adding this to the arson list
        targetbullshit+=1 if ((@realtarget.index==0 || @realtarget.index==2) && !@isOppMove)
        targetbullshit-=1 if ((@realtarget.index==1 || @realtarget.index==3) && @isOppMove)
        cel = thisframe[targetbullshit-2] if targetbullshit>1
        cel = thisframe[targetbullshit] if targetbullshit<2 #cel of target
        pbSpriteSetAnimFrame(@target1sprite,cel,@usersprite,@target1sprite) #for sprite 1
        case cel[AnimFrame::FOCUS]
          when 1   # Focused on target
            if targetbullshit==1 || (targetbullshit-2)==1
              @target1sprite.x=cel[AnimFrame::X]+@target1Orig[0]-PBScene::FOCUSTARGET_X
              @target1sprite.y=cel[AnimFrame::Y]+@target1Orig[1]-PBScene::FOCUSTARGET_Y
            else
              @target1sprite.x=cel[AnimFrame::X]+@userOrig[0]-PBScene::FOCUSTARGET_X
              @target1sprite.y=cel[AnimFrame::Y]+@userOrig[1]-PBScene::FOCUSTARGET_Y
            end   
            when 2   # Focused on user
              if targetbullshit==1 || (targetbullshit-2)==1
                @target1sprite.x=cel[AnimFrame::X]+@userOrig[0]-PBScene::FOCUSUSER_X
                @target1sprite.y=cel[AnimFrame::Y]+@userOrig[1]-PBScene::FOCUSUSER_Y
              else
                @target1sprite.x=cel[AnimFrame::X]+@target1Orig[0]-PBScene::FOCUSUSER_X
                @target1sprite.y=cel[AnimFrame::Y]+@target1Orig[1]-PBScene::FOCUSUSER_Y
              end
            when 3   # Focused on user and target
              point=transformPoint(
                @target1line[0],@target1line[1],@target1line[2],@target1line[3],
                @target1line[4],@target1line[5],@target1line[6],@target1line[7],
                @target1sprite.x,@target1sprite.y)
              @target1sprite.x=point[0]
              @target1sprite.y=point[1]
              if isReversed(@target1line[0],@target1line[2],@target1line[4],@target1line[6]) &&
                cel[AnimFrame::PATTERN]>=0 && @animation.oppflip != false
                # Reverse direction
                @target1sprite.mirror=!@target1sprite.mirror
              end
        end
        if @target2sprite
          pbSpriteSetAnimFrame(@target2sprite,cel,@usersprite,@target2sprite) #for sprite 2 if it exists
          case cel[AnimFrame::FOCUS]
           when 1   # Focused on target
              if targetbullshit==1 || (targetbullshit-2)==1
                @target2sprite.x=cel[AnimFrame::X]+@target2Orig[0]-PBScene::FOCUSTARGET_X
                @target2sprite.y=cel[AnimFrame::Y]+@target2Orig[1]-PBScene::FOCUSTARGET_Y
              else
                @target2sprite.x=cel[AnimFrame::X]+@userOrig[0]-PBScene::FOCUSTARGET_X
                @target2sprite.y=cel[AnimFrame::Y]+@userOrig[1]-PBScene::FOCUSTARGET_Y
              end   
              when 2   # Focused on user
                if targetbullshit==1 || (targetbullshit-2)==1
                  @target2sprite.x=cel[AnimFrame::X]+@userOrig[0]-PBScene::FOCUSUSER_X
                  @target2sprite.y=cel[AnimFrame::Y]+@userOrig[1]-PBScene::FOCUSUSER_Y
                else
                  @target2sprite.x=cel[AnimFrame::X]+@target2Orig[0]-PBScene::FOCUSUSER_X
                  @target2sprite.y=cel[AnimFrame::Y]+@target2Orig[1]-PBScene::FOCUSUSER_Y
                end
              when 3   # Focused on user and target
                point=transformPoint(
                  @target2line[0],@target2line[1],@target2line[2],@target2line[3],
                  @target2line[4],@target2line[5],@target2line[6],@target2line[7],
                  @target2sprite.x,@target2sprite.y)
                @target2sprite.x=point[0]
                @target2sprite.y=point[1]
                if isReversed(@target2line[0],@target2line[2],@target2line[4],@target2line[6]) &&
                  cel[AnimFrame::PATTERN]>=0 && @animation.oppflip != false
                  # Reverse direction
                  @target2sprite.mirror=!@target2sprite.mirror
                end
            end
          end
      end
      # Play timings
      @animation.playTiming(@frame>>1,@bgGraphic,@bgColor,@foGraphic,@foColor,@oldbg,@oldfo,@user,@target,@isAutoOpp)
    end
    @frame+=3
   end
  end
  
  
  
  class PokeBattle_Battler
  
        def pbFaint(showMessage=true)
        if !self.isFainted?
          PBDebug.log("!!!***Can't faint with HP greater than 0") if $INTERNAL
          return true
        end
        if @fainted
          return true
        end
        # LAWDS - Little King's Mark goes away when it leaves the field
        if self.ability== :LITTLEKING && self.pbPartner.ability != :LITTLEKING
          pbOppositeOpposing.effects[:LittleKingTarget] = false
          pbOppositeOpposing.pbPartner.effects[:LittleKingTarget] = false
        end
        if self.isbossmon
          if self.shieldCount > 0 && self.onBreakEffects
            onBreakdata = self.onBreakEffects[self.shieldCount]
            if !@battle.snapshot.nil?
              if @battle.snapshot[1]
                if @battle.snapshot[1][5]==0
                  onBreakdata = self.onBreakEffects[self.shieldCount*(-1)]
                end
              end
            end
            hpthreshold = (onBreakdata && onBreakdata[:threshold]) ? onBreakdata[:threshold] : 0
            #self.pbRecoverHP(self.totalhp,true) if self.hp==0
            case hpthreshold
            when 0
              boss = @battle.battlers[self.index] 
              self.pbRecoverHP(self.totalhp,true)
              @battle.pbShieldEffects(self,onBreakdata) if onBreakdata
              self.shieldCount-=1 if self.shieldCount>0 
              @battle.scene.pbUpdateShield(boss.shieldCount,self.index)
              if boss.sosDetails
                @battle.pbBossSOS(@battle.battlers,shieldbreak=true)
              end
            when 0.1
              self.pbRecoverHP(self.totalhp,true)
              if onBreakdata
                if onBreakdata[:thresholdmessage] && onBreakdata[:thresholdmessage] != ""
                  if onBreakdata[:thresholdmessage].start_with?("{1}") 
                    pbDisplay(_INTL(onBreakdata[:thresholdmessage],self.pbThis))
                  else
                    pbDisplay(_INTL(onBreakdata[:thresholdmessage],self.pbThis(true)))
                  end
                end
                @battle.pbShieldEffects(self,onBreakdata,false,false,true) if onBreakdata
                self.reconstructcounter += 1
                if self.reconstructcounter >=100      
                  if $game_variables[731] < 122 && $game_variables[756] < 85
                  @battle.pbDisplayBrief(_INTL("???: You are wasting your time, Interceptor.",self.pbThis))
                  else
                    @battle.pbDisplayBrief(_INTL("A lost voice echoed in your head...",self.pbThis))
                    @battle.pbDisplayBrief(_INTL("???: You are wasting your time, Interceptor.",self.pbThis))
                  end
                  @battle.pbAnimation(:ROAROFTIME,self,nil)
                  @battle.decision = 2
                  @battle.pbJudge()
                  # if @battle.decision > 0
                  #   return
                  # end
                elsif self.reconstructcounter >=3
                  pbDisplayBrief(_INTL("{1} seems indestructible...",self.pbThis))
                end
              end
            end
            return false
          end
        end
        @battle.returnStolenPokemon(false,self,self.lastAttacker) if self.issossmon
        if ((@species==:PARAS && @pokemon.form==1 || @species==:PARASECT && @pokemon.form==1) && @ability== :RESUSCITATION)
          @battle.scene.pbFakeOutFainted(self)
          #@effects[PBEffects::Resusitated]=true
          pbUpdate(true)
          self.pbRecoverHP((self.totalhp).floor,true)
          @battle.pbDisplayPaused(_INTL("{1} was resuscitated!",self.pbThis))
          if @battle.FE==:HAUNTED
            for i in [PBStats::ATTACK,PBStats::DEFENSE,PBStats::SPEED,
              PBStats::SPATK,PBStats::SPDEF,PBStats::EVASION,PBStats::ACCURACY]
              @stages[i]=0 if @stages[i]<0
            end
          end
          return false
        else
          @battle.scene.pbFainted(self)     
        end
        @battle.neutralizingGasDisable(self.index) if self.ability== :NEUTRALIZINGGAS
        if (pbPartner.ability==:POWEROFALCHEMY || pbPartner.ability==:RECEIVER) && pbPartner.item != :ABILITYSHIELD && pbPartner.hp > 0
          if PBStuff::ABILITYBLACKLIST.none? {|forbidden_ability| forbidden_ability==@ability}
          # lawds p3
            abilityindex=-1
            if pbPartner.ability.is_a?(PokeAbility)
              if pbPartner.ability.ability.is_a?(Array)
                abilityindex=0
                for i in 0...pbPartner.ability.ability.length # partner has multiple abilities
                  if [:POWEROFALCHEMY,:RECEIVER].include?(pbPartner.ability.ability[i])
                    abilityindex=i 
                    break
                  end
                end
              end
            end
            partnerability=self.ability
            if self.ability.is_a?(PokeAbility)
              if self.ability.ability.is_a?(Array)
                copiedabil=self.ability.ability # self has multiple abilities
              else
                copiedabil=[self.ability.ability] # self has one ability
              end
              if abilityindex==-1 # partner has one ability
                partnerability = copiedabil
                partnerability=copiedabil[0] if copiedabil.length==1 
              else
                abilarray = []
                for abil in copiedabil # add every copyable ability to the array
                  abilarray.push(abil) if !PBStuff::ABILITYBLACKLIST.include?(abil)
                end
                copiedabil=abilarray.clone # save all the abilities we've copied for later
                for i in 0...pbPartner.ability.ability.length # add every ability had by the partner to the array, except receiver/alchemy
                   if i != abilityindex && !abilarray.include?(i)
                    abilarray.push(pbPartner.ability.ability[i])
                   end
                end
                partnerability=abilarray
              end
            end
            oldability= pbPartner.ability
            pbPartner.ability=copiedabil # assign copied abilities to partner
            abilityname=getAbilityName(partnerability)
            abilityname="Abilities" if partnerability.is_a?(Array) || (partnerability.is_a?(PokeAbility) && partnerability.ability.is_a?(Array))
            if oldability==:POWEROFALCHEMY
              @battle.pbDisplay(_INTL("{1} took on {2}'s {3}!",pbPartner.pbThis,pbThis,abilityname))
            else
              @battle.pbDisplay(_INTL("{1} received {2}'s {3}!",pbPartner.pbThis,pbThis,abilityname))
            end
            pbPartner.pbAbilitiesOnSwitchIn(true,true) # run abilities on switch in for the new abilities, then assign the full ability array
            pbPartner.ability=partnerability
          end
          # end lawds p3 stuff
        end
        for i in @battle.battlers
          next if i.isFainted?
          if i.ability== :SOULHEART && !i.pbTooHigh?(PBStats::SPATK)
            @battle.pbDisplay(_INTL("{1}'s Soul-heart activated!",i.pbThis))
            i.pbIncreaseStat(PBStats::SPATK,1)
            if (@battle.FE==:MISTY || @battle.FE==:RAINBOW || @battle.FE==:FAIRYTALE) && !i.pbTooHigh?(PBStats::SPDEF)
              i.pbIncreaseStat(PBStats::SPDEF,1)
            end
          end
        end
        droprelease = self.effects[:SkyDroppee]
        #if locked in sky drop while fainting
        if self.effects[:SkyDrop]
          for i in @battle.battlers
            next if i.isFainted?
            if i.effects[:SkyDroppee]==self
              @battle.scene.pbUnVanishSprite(i)
              i.effects[:TwoTurnAttack] = 0
              i.effects[:SkyDroppee] = nil
            end
          end
        end
        # Gen 9 Mod - Get Tatsugiri out of Dondozo's mouth when Dondozo faints
        if self.effects[:Commandee] && self.pbPartner.effects[:Commander]
          self.pbPartner.effects[:Commander] = false
          @battle.scene.pbUnVanishSprite(self.pbPartner,true)
        end
        @battle.pbDisplayBrief(_INTL("{1} fainted!",pbThis)) if showMessage
        pbInitEffects(false)
        self.bossdelayedeffect = nil
        self.bossdelaycounter = nil
        self.onEntryEffects = nil
        self.vanished=false
        # reset status
        self.status=nil
        self.statusCount=0
        if @pokemon && @battle.internalbattle
          @pokemon.changeHappiness("faint")
        end
        if self.isMega?
          @pokemon.makeUnmega
        end
        if self.isUltra?
          @pokemon.makeUnultra(@startform)
        end
        @fainted=true
        # reset choice
        @battle.choices[@index]=[0,0,nil,-1]
        if @userSwitch
          @userSwitch = false
        end
        #reset mimikyu form if it faints
        if (@species==:MIMIKYU || @species==:EISCUE) && @pokemon.form==1
          self.form=0
        end
        if ((@species == :PARAS || @species == :PARASECT) && @pokemon.form == 2)
          self.form=1 
        end
        #stops being in middle of a spread move
        @midwayThroughMove = false
        #deactivate ability
        self.ability=nil
        self.crested=false
        if droprelease!=nil
          oppmon = droprelease
          oppmon.effects[:SkyDrop]=false
          @battle.scene.pbUnVanishSprite(oppmon)
          @battle.pbDisplay(_INTL("{1} is freed from Sky Drop effect!",oppmon.pbThis))
        end
        @battle.party2.pop if self.issossmon
        # set ace message flag
        if (self.index==1 || self.index==3) && !@battle.pbIsWild? && !@battle.opponent.is_a?(Array) && @battle.pbPokemonCount(@battle.party2)==1 && !@battle.ace_message_handled
          @battle.ace_message=true
        end
        @battle.scene.partyBetweenKO1(self.index==1 || self.index==3) unless (@battle.doublebattle || pbNonActivePokemonCount==0)
        PBDebug.log("[#{pbThis} fainted]") if $INTERNAL
        return true
      end
end

class PBAnimation < Array
  include Enumerable
  attr_accessor :graphic
  attr_accessor :hue 
  attr_accessor :name
  attr_accessor :position
  attr_accessor :speed
  attr_reader :array
  attr_reader :timing
  attr_accessor :id
  attr_accessor :targets 
  attr_accessor :oppflip
  attr_accessor :foreflip  
  MAXSPRITES=100

  def speed
    @speed=20 if !@speed
    return @speed
  end

  def initialize(size=1)
    @array=[]
    @timing=[]
    @name=""
    @id=-1
    @graphic=""
    @hue=0
    @scope=0
    @position=4 # 1=target, 2=user, 3=user and target, 4=screen
    @targets=0 # 0 = "Single Target",1 = "Both Opponents", 2 = "All Targets", 3 ="Hide Partners"
    @oppflip=false
    @foreflip=false
    size=1 if size<1 # Always create at least one frame
    size.times do
      addFrame
    end
  end

  def length
    return @array.length
  end

  def targets
    @targets=0 if @targets==nil
    return @targets
  end

  def oppflip
    @oppflip=true if @oppflip==nil
    return @oppflip
  end

  def foreflip
    @foreflip=false if @foreflip==nil
    return @foreflip
  end

  def each
    @array.each {|i| yield i }
  end

  def [](i)
    return @array[i]
  end

  def []=(i,value)
    @array[i]=value
  end

  def insert(*arg)
    return @array.insert(*arg)
  end

  def delete_at(*arg)
    return @array.delete_at(*arg)
  end

  def playTiming(frame,bgGraphic,bgColor,foGraphic,foColor,oldbg=[],oldfo=[],user=nil,target=nil,autoopp=false)
    for i in @timing
      if i.frame==frame
        case i.timingType
          when 0   # Play SE
            if i.name && i.name!=""
              pbSEPlay(i.name,i.volume,i.pitch)
            else
              poke=(user && user.pokemon) ? user.pokemon : 1
              name=(pbCryFile(poke) rescue "001Cry")
              pbSEPlay(name,i.volume,i.pitch)
            end
          when 1   # Set background graphic (immediate)
            if i.name && i.name!=""
              bgGraphic.setBitmap("Graphics/Animations/"+i.name)
              bgGraphic.ox=-i.bgX || 0
              bgGraphic.oy=-i.bgY || 0
              bgGraphic.color=Color.new(i.colorRed || 0,i.colorGreen || 0,i.colorBlue || 0,i.colorAlpha || 0)
              bgGraphic.opacity=i.opacity || 0
              bgColor.opacity=0
            else
              bgGraphic.setBitmap(nil)
              bgGraphic.opacity=0
              bgColor.color=Color.new(i.colorRed || 0,i.colorGreen || 0,i.colorBlue || 0,i.colorAlpha || 0)
              bgColor.opacity=i.opacity || 0
            end
          when 2   # Move/recolour background graphic
            if bgGraphic.bitmap!=nil
              oldbg[0]=bgGraphic.ox || 0
              oldbg[1]=bgGraphic.oy || 0              
              oldbg[2]=bgGraphic.opacity || 0
              @@oldopacity=oldbg[2]
              oldbg[3]=bgGraphic.color.clone || Color.new(0,0,0,0)
              @@oldcolor=oldbg[3]
            else
              oldbg[0]=0
              oldbg[1]=0
              oldbg[2]=bgColor.opacity || 0
              @@oldopacity=oldbg[2]
              oldbg[3]=bgColor.color.clone || Color.new(0,0,0,0)
              @@oldcolor=oldbg[3]
            end
          when 3   # Set foreground graphic (immediate)
            if i.name && i.name!=""
              foGraphic.setBitmap("Graphics/Animations/"+i.name)
              foGraphic.ox=-i.bgX || 0
              foGraphic.oy=-i.bgY || 0
              foGraphic.color=Color.new(i.colorRed || 0,i.colorGreen || 0,i.colorBlue || 0,i.colorAlpha || 0)
              foGraphic.opacity=i.opacity || 0
              foColor.opacity=0
            else
              foGraphic.setBitmap(nil)
              foGraphic.opacity=0
              foColor.color=Color.new(i.colorRed || 0,i.colorGreen || 0,i.colorBlue || 0,i.colorAlpha || 0)
              foColor.opacity=i.opacity || 0
            end
          when 4   # Move/recolour foreground graphic

			
        end
      end
    end
    for i in @timing
      case i.timingType
        when 2

        when 4

      end
    end
  end
 
  def resize(len)
    if len<@array.length
      @array[len,@array.length-len]=[]
    elsif len>@array.length
      (len-@array.length).times do
        addFrame
      end
    end
  end

  def addFrame
    pos=@array.length
    @array[pos]=[]
    for i in 0...PBAnimation::MAXSPRITES # maximum sprites plus user and target
      if i==0
        @array[pos][i]=pbCreateCel(
           PBScene::FOCUSUSER_X,
           PBScene::FOCUSUSER_Y,-1) # Move's user
        @array[pos][i][AnimFrame::FOCUS]=2
        @array[pos][i][AnimFrame::LOCKED]=1
      elsif i==1
        @array[pos][i]=pbCreateCel(
           PBScene::FOCUSTARGET_X,
           PBScene::FOCUSTARGET_Y,-2) # Move's target
        @array[pos][i][AnimFrame::FOCUS]=1
        @array[pos][i][AnimFrame::LOCKED]=1
      end
    end
    return @array[pos]
  end
end

def isReversed(src0,src1,dst0,dst1)
  if src0==src1
    return false
  elsif src0<src1
    return (dst0>dst1)
  else
    return (dst0<dst1)
  end
end

class RPG::Animation

def pbSpriteSetAnimFrame(sprite,frame,user=nil,target=nil,ineditor=false)
  return if !sprite
  if !frame
    sprite.visible=false
    sprite.src_rect=Rect.new(0,0,1,1)
    return
  end
  trimFrame(frame) if frame.length > 20
  sprite.blend_type=frame[AnimFrame::BLENDTYPE]
  sprite.angle = (@isAutoOpp==true && frame[AnimFrame::FOCUS]==3 && frame[AnimFrame::PATTERN]<0) ? 360-frame[AnimFrame::ANGLE] : frame[AnimFrame::ANGLE]
  sprite.mirror=(frame[AnimFrame::MIRROR]>0)
  sprite.opacity=frame[AnimFrame::OPACITY]
  sprite.visible=true
  target.visible=false if !target.nil? && @target && @target.is_a?(PokeBattle_Battler) && (@target.isFainted? && !(Rejuv && @target.isbossmon && @target.shieldCount>0)) 
  @animpartner.visible=@target.pbPartner.isFainted? ? false : true if @target && @target.is_a?(PokeBattle_Battler) && @partnerbs
  pattern=frame[AnimFrame::PATTERN]
  if pattern>=0
#    if sprite.bitmap && !sprite.bitmap.disposed?
#      animwidth=sprite.bitmap.width/5
#      #echo(animwidth.inspect+"\r\n")
#    else
#      animwidth=192
#    end
    animwidth=192
    sprite.src_rect.set((pattern%5)*animwidth,(pattern/5)*animwidth,
       animwidth,animwidth)
  elsif !sprite.disposed? && !sprite.bitmap.disposed? && sprite.bitmap
    sprite.src_rect.set(0,0,
       sprite.bitmap ? sprite.bitmap.width : 128,
       sprite.bitmap ? sprite.bitmap.height : 128)
  end
  sprite.zoom_x=frame[AnimFrame::ZOOMX]/100.0
  sprite.zoom_y=frame[AnimFrame::ZOOMY]/100.0
  sprite.color.set(
     frame[AnimFrame::COLORRED],
     frame[AnimFrame::COLORGREEN],
     frame[AnimFrame::COLORBLUE],
     frame[AnimFrame::COLORALPHA]
  )
  sprite.tone.set(
     frame[AnimFrame::TONERED],
     frame[AnimFrame::TONEGREEN],
     frame[AnimFrame::TONEBLUE],
     frame[AnimFrame::TONEGRAY] 
  )
  sprite.ox=sprite.src_rect.width/2
  sprite.oy=sprite.src_rect.height/2
  sprite.x=frame[AnimFrame::X]
  sprite.y=frame[AnimFrame::Y]
  if sprite!=user && sprite!=target
    case frame[AnimFrame::PRIORITY]
      when 0   # Behind everything
        sprite.z=5
      when 1   # In front of everything
        sprite.z=35
      when 2   # Just behind focus
        if frame[AnimFrame::FOCUS]==1 # Focused on target
          sprite.z=(target) ? target.z-1 : 5
        elsif frame[AnimFrame::FOCUS]==2 # Focused on user
          sprite.z=(user) ? user.z-1 : 5
        else # Focused on user and target, or screen
          sprite.z=5
        end
      when 3   # Just in front of focus
        if frame[AnimFrame::FOCUS]==1 # Focused on target
          sprite.z=(target) ? target.z+1 : 35
        elsif frame[AnimFrame::FOCUS]==2 # Focused on user
          sprite.z=(user) ? user.z+1 : 35
        else # Focused on user and target, or screen
          sprite.z=35
        end
      when 4 #Between player/foe sides
        sprite.z=18
      when 5 #In front of player side/behind opponent side
        if @ineditor==false
          if target.x<256 #Player side
            sprite.z=35
          else
            sprite.z=5
          end
        else
          if sprite.x<256
            sprite.z=35
          else
            sprite.z=5
          end
        end
      else
        sprite.z=35
    end
  end
end
end
