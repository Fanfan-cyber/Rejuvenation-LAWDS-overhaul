class PokemonEncounters
  def pbShouldFilterKnownPkmnFromEncounter?
    return false if $Trainer.party[0].item == :MIRRORLURE
    return true ###### MOD ######
  end
end

class PokeBattle_Battle 
  def pbCanRun?(idxPokemon)
    return true ###### MOD ######
  end
end