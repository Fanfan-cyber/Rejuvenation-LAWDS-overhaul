###### MOD ######
Events.onSpritesetCreate+=proc{|sender,e|
  spriteset=e[0]
  viewport=e[1]
  map=spriteset.map
  for i in map.events.keys
  	event = map.events[i]
  	next if $PokemonBag.nil?
  	next if $PokemonBag.pbQuantity(:ITEMFINDER)==0
  	if map.map_id == 58 && event.id == 8
  		event.character_name = "ItemFinderUnhideBall"
  		event.through = true
  	end
    next if event.name != 'HiddenItem'
    next if map.map_id == 48 && event.id == 9
    next if $game_self_switches[[$game_map.map_id, event.id, 'A']]
		next if $game_self_switches[[$game_map.map_id, event.id, 'B']]
		next if $game_self_switches[[$game_map.map_id, event.id, 'C']]
		next if $game_self_switches[[$game_map.map_id, event.id, 'D']]
    event.character_name = "ItemFinderUnhideBall"
    event.through = true
  end
}

ItemHandlers::UseInField.add(:ITEMFINDER,proc{|item|
	Kernel.pbMessage(_INTL("The ITEMFINDER is always ON because you are using a Mod"))
})
###### MOD ######