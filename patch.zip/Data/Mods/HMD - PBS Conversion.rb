def convertPBS
  Dir.mkdir ("Scripts/"+GAMEFOLDER+"/ConvertedDOH") if !Dir.exist?("Scripts/"+GAMEFOLDER+"/ConvertedDOH")
  if !Dir.exist?("PBS")
    Kernel.pbMessage("Please download the PBS files to the root folder of the game before proceeding.")
    return
  end
  choices = [
    "Pokemon",
    "Trainers",
    "Encounters",
    "Map Connections (Not Recommended)",
    "Metadata (Strongly Not Recommended)"
  ]
  loop do
    choice = Kernel.pbMessage("Which would you like to convert?",choices,-1)
    case choice
      when -1 then break
      when 0
        if File.exist?("PBS/pokemon.txt")
          convertMons
        else
          cprint "pokemon.txt could not be found."
        end
      when 1
        if File.exist?("PBS/trainertypes.txt")
          converttypes
        else
          cprint "trainertypes.txt could not be found."
        end
        if File.exist?("PBS/trainers.txt")
          convertTeam
        else
          cprint "trainers.txt could not be found."
        end
      when 2
        if File.exist?("PBS/encounters.txt")
          convertEnc
        else
          cprint "encounters.txt could not be found."
        end
      when 3
        if File.exist?("PBS/connections.txt")
          convertCon
        else
          cprint "connections.txt could not be found."
        end
      when 4
        if File.exist?("PBS/metadata.txt")
          convertMeta
        else
          cprint "metadata.txt could not be found."
        end
    end
  end
end

def convertMeta
  sections=[]
  currentmap=-1
  pbCompilerEachCommentedLine("PBS/metadata.txt") {|line,lineno|
      if line[/^\s*\[\s*(\d+)\s*\]\s*$/]
        sectionname=$~[1]
        if currentmap==0
          if sections[currentmap][1]==nil
            raise _INTL("The entry Home is required in metadata.txt section [{1}]",sectionname)
          end
          if sections[currentmap][10]==nil
            raise _INTL("The entry PlayerA is required in metadata.txt section [{1}]",sectionname)
          end
        end
        currentmap=sectionname.to_i
        sections[currentmap]=[]
      else
        if currentmap<0
          raise _INTL("Expected a section at the beginning of the file\r\n{1}",FileLineData.linereport)
        end
        if !line[/^\s*(\w+)\s*=\s*(.*)$/]
          raise _INTL("Bad line syntax (expected syntax like XXX=YYY)\r\n{1}",FileLineData.linereport)
        end
        matchData=$~
        schema=nil
        FileLineData.setSection(currentmap,matchData[1],matchData[2])
        if currentmap==0
          schema=PokemonMetadata::GlobalTypes[matchData[1]]
        else
          schema=PokemonMetadata::NonGlobalTypes[matchData[1]]
        end
        if schema
          record=pbGetCsvRecord(matchData[2],lineno,schema)
          sections[currentmap][schema[0]]=record
        end
      end
  }

  metadata = sections
  exporttext = "METAHASH = {\n"
  exporttext += ":home => #{metadata[0][1].inspect},\n"
  exporttext += ":TrainerVictory => \"#{metadata[0][5]}\",\n"
  exporttext += ":WildVictory => \"#{metadata[0][4]}\",\n"
  exporttext += ":TrainerBattle => \"#{metadata[0][3]}\",\n"
  exporttext += ":WildBattle => \"#{metadata[0][2]}\",\n"
  exporttext += ":Surf => \"#{metadata[0][6]}\",\n"
  exporttext += ":Bicycle => \"#{metadata[0][7]}\",\n\n"
  for i in 8...metadata[0].length
    exporttext += ":player#{i-7} => {\n"
    exporttext += "\t:tclass => :#{metadata[0][i][0]},\n"
    exporttext += "\t#sprites,\n"
    exporttext += "\t:walk => \"#{metadata[0][i][1]}\",\n" if metadata[0][i][1] != ""
    exporttext += "\t:run => \"#{metadata[0][i][4]}\",\n" if metadata[0][i][4] != ""
    exporttext += "\t:bike => \"#{metadata[0][i][2]}\",\n" if metadata[0][i][2] != ""
    exporttext += "\t:surf => \"#{metadata[0][i][3]}\",\n" if metadata[0][i][3] != ""
    exporttext += "\t:dive => \"#{metadata[0][i][5]}\",\n" if metadata[0][i][5] != ""
    exporttext += "\t:fishing => \"#{metadata[0][i][6]}\",\n" if metadata[0][i][6] != ""
    exporttext += "\t:surffish => \"#{metadata[0][i][7]}\",\n" if metadata[0][i][7] != ""
    exporttext += "},\n\n"
  end
  for i in 1...metadata.length
    if metadata[i].nil?
      if $cache.mapinfos[i]
        exporttext += "\##{$cache.mapinfos[i].name}\n"
      end
      exporttext += "#{i} => {}, \n\n"
      next
    end
    if $cache.mapinfos[i]
      exporttext += "\##{$cache.mapinfos[i].name}\n"
    end
    exporttext += "#{i} => { \n"
    exporttext += "\t:HealingSpot => #{metadata[i][MetadataHealingSpot].inspect},\n" if metadata[i][MetadataHealingSpot]
    exporttext += "\t:MapPosition => #{metadata[i][MetadataMapPosition].inspect},\n" if metadata[i][MetadataMapPosition]
    exporttext += "\t:Outdoor => #{metadata[i][MetadataOutdoor]},\n" if metadata[i][MetadataOutdoor]
    exporttext += "\t:ShowArea => #{metadata[i][MetadataShowArea]},\n" if metadata[i][MetadataShowArea]
    exporttext += "\t:Bicycle => #{metadata[i][MetadataBicycle]},\n" if metadata[i][MetadataBicycle]
    exporttext += "\t:BicycleAlways => #{metadata[i][MetadataBicycleAlways]},\n" if metadata[i][MetadataBicycleAlways]
    exporttext += "\t:Weather => #{metadata[i][MetadataWeather]},\n" if metadata[i][MetadataWeather]
    exporttext += "\t:DiveMap => #{metadata[i][MetadataDiveMap]},\n" if metadata[i][MetadataDiveMap]
    exporttext += "\t:DarkMap => #{metadata[i][MetadataDarkMap]},\n" if metadata[i][MetadataDarkMap]
    exporttext += "\t:SafariMap => #{metadata[i][MetadataSafariMap]},\n" if metadata[i][MetadataSafariMap]
    exporttext += "\t:SnapEdges => #{metadata[i][MetadataSnapEdges]},\n" if metadata[i][MetadataSnapEdges]
    exporttext += "\t:Dungeon => #{metadata[i][MetadataDungeon]},\n" if metadata[i][MetadataDungeon]
    exporttext += "\t:BattleBack => \"#{metadata[i][MetadataBattleBack]}\",\n" if metadata[i][MetadataBattleBack]
    exporttext += "\t:WildBattleBGM => \"#{metadata[i][MetadataMapWildBattleBGM]}\",\n" if metadata[i][MetadataMapWildBattleBGM]
    exporttext += "\t:TrainerBattleBGM => \"#{metadata[i][MetadataMapTrainerBattleBGM]}\",\n" if metadata[i][MetadataMapTrainerBattleBGM]
    exporttext += "\t:WildVictoryME => \"#{metadata[i][MetadataMapWildVictoryME]}\",\n" if metadata[i][MetadataMapWildVictoryME]
    exporttext += "\t:TrainerVictoryME => \"#{metadata[i][MetadataMapTrainerVictoryME]}\",\n" if metadata[i][MetadataMapTrainerVictoryME]
    exporttext += "\t:MapSize => #{metadata[i][MetadataMapSize]},\n" if metadata[i][MetadataMapSize]
    exporttext += "},\n\n"
  end
  exporttext += "}"
  File.open("Scripts/"+GAMEFOLDER+"/ConvertedDOH/metatext.rb","w"){|f|
    f.write(exporttext)
  }
end

# conversion stuff
  MetadataHome             = 1
  MetadataStorageCreator   = 2
  MetadataWildBattleBGM    = 3
  MetadataTrainerBattleBGM = 4
  MetadataWildVictoryME    = 5
  MetadataTrainerVictoryME = 6
  MetadataTextSkin         = 7
  MetadataSurfBGM          = 8
  MetadataBicycleBGM       = 9
  MetadataPlayerA          = 10
  MetadataPlayerB          = 11
  MetadataPlayerC          = 12
  MetadataPlayerD          = 13
  MetadataPlayerE          = 14
  MetadataPlayerF          = 15
  MetadataPlayerG          = 16
  MetadataPlayerH          = 17
  MetadataPlayerI          = 18
  MetadataPlayerJ          = 19
  MetadataPlayerK          = 20
  MetadataPlayerL          = 21
  MetadataPlayerM          = 22
  MetadataPlayerN          = 23
  MetadataPlayerO          = 24
  MetadataPlayerP         = 25
  MetadataPlayerQ          = 26
  MetadataPlayerR          = 27
  MetadataPlayerS          = 28

  MetadataOutdoor             = 1
  MetadataShowArea            = 2
  MetadataBicycle             = 3
  MetadataBicycleAlways       = 4
  MetadataHealingSpot         = 5
  MetadataWeather             = 6
  MetadataMapPosition         = 7
  MetadataDiveMap             = 8
  MetadataDarkMap             = 9
  MetadataSafariMap           = 10
  MetadataSnapEdges           = 11
  MetadataDungeon             = 12
  MetadataBattleBack          = 13
  MetadataMapWildBattleBGM    = 14
  MetadataMapTrainerBattleBGM = 15
  MetadataMapWildVictoryME    = 16
  MetadataMapTrainerVictoryME = 17
  MetadataMapSize             = 18



  module PokemonMetadata
    GlobalTypes={
      "Home"=>[1,"uuuu"],
      "StorageCreator"=>[2,"s"],
      "WildBattleBGM"=>[3,"s"],
      "TrainerBattleBGM"=>[4,"s"],
      "WildVictoryME"=>[5,"s"],
      "TrainerVictoryME"=>[6,"s"],
      "TextSkin"=>[7,"s"],
      "SurfBGM"=>[8,"s"],
      "BicycleBGM"=>[9,"s"],
      "PlayerA"=>[10,"ssssssss"],
      "PlayerB"=>[11,"ssssssss"],
      "PlayerC"=>[12,"ssssssss"],
      "PlayerD"=>[13,"ssssssss"],
      "PlayerE"=>[14,"ssssssss"],
      "PlayerF"=>[15,"ssssssss"],
      "PlayerG"=>[16,"ssssssss"],
      "PlayerH"=>[17,"ssssssss"],
      "PlayerI"=>[18,"ssssssss"],
      "PlayerJ"=>[19,"ssssssss"],
      "PlayerK"=>[20,"ssssssss"],
      "PlayerL"=>[21,"ssssssss"],
      "PlayerM"=>[22,"ssssssss"],
      "PlayerN"=>[23,"ssssssss"],
      "PlayerO"=>[24,"ssssssss"],
      "PlayerP"=>[25,"ssssssss"],
      "PlayerQ"=>[26,"ssssssss"],
      "PlayerR"=>[27,"ssssssss"],
            "PlayerS"=>[28,"ssssssss"]

    }
    NonGlobalTypes={
      "Outdoor"=>[1,"b"],
      "ShowArea"=>[2,"b"],
      "Bicycle"=>[3,"b"],
      "BicycleAlways"=>[4,"b"],
      "HealingSpot"=>[5,"uuu"],
      "Weather"=>[6,"eu",["","Rain","Storm","Snow","Sandstorm","Sunny"]],
      "MapPosition"=>[7,"uuu"],
      "DiveMap"=>[8,"u"],
      "DarkMap"=>[9,"b"],
      "SafariMap"=>[10,"b"],
      "SnapEdges"=>[11,"b"],
      "Dungeon"=>[12,"b"],
      "BattleBack"=>[13,"s"],
      "WildBattleBGM"=>[14,"s"],
      "TrainerBattleBGM"=>[15,"s"],
      "WildVictoryME"=>[16,"s"],
      "TrainerVictoryME"=>[17,"s"],
      "MapSize"=>[18,"us"],
    }
  end
#

def converttypes
  records=[]
  trainernames=[]
  count=0
  maxValue=0
  pbCompilerEachCommentedLine("PBS/trainertypes.txt"){|line,lineno|
    begin
     record=pbGetCsvRecord(line,lineno,[0,"unsUSSSeU", # ID can be 0
        nil,nil,nil,nil,nil,nil,nil,{
        ""=>2,
        "Male"=>0,"M"=>0,"0"=>0,
        "Female"=>1,"F"=>1,"1"=>1,
        "Mixed"=>2,"X"=>2,"2"=>2
       },nil]
     )
    rescue
      next 
    end
     if record[3] && (record[3]<0 || record[3]>255)
       raise _INTL("Bad money amount (must be from 0 through 255)\r\n{1}",FileLineData.linereport)
     end
     record[3]=30 if !record[3]
     if record[8] && (record[8]<0 || record[8]>255)
      raise _INTL("Bad skill value (must be from 0 through 255)\r\n{1}",FileLineData.linereport)
     end
     record[8] = record[3] if !record[8]
     trainernames[record[0]]=record[2]
     if records[record[0]]
       raise _INTL("Two trainer types ({1} and {2}) have the same ID ({3}), which is not allowed.\r\n{4}",
          records[record[0]][1],record[1],record[0],FileLineData.linereport)
     end
     records[record[0]]=record
     maxValue=[maxValue,record[0]].max
  }
  print records[1]
  exporttext = "TTYPEHASH = {\n"
  for ttype in records
    next if !ttype || ttype.empty?
    exporttext += ":#{ttype[1]} => {\n"
    exporttext += "\t:ID => #{ttype[0]},\n"
    exporttext += "\t:title => \"#{ttype[2]}\",\n"
    exporttext += "\t:skill => #{ttype[8]},\n"
    exporttext += "\t:moneymult => #{ttype[3]},\n" if ttype[3] != 0
    exporttext += "\t:battleBGM => \"#{ttype[4]}\",\n" if ttype[4]
    exporttext += "\t:winBGM => \"#{ttype[5]}\",\n" if ttype[5]
    exporttext += "},\n\n"
  end
  exporttext += "}"
  File.open("Scripts/"+GAMEFOLDER+"/ConvertedDOH/ttypetext.rb","w"){|f|
    f.write(exporttext)
  }
end

def convertEnc
  pbENCSTART=4
  lines=[]
  linenos=[]
  FileLineData.file="PBS/encounters.txt"
  File.open("PBS/encounters.txt","rb"){|f|
     lineno=1
     f.each_line {|line|
        line=prepline(line)
        if line.length!=0
          lines[lines.length]=line
          linenos[linenos.length]=lineno
        end
        lineno+=1
     }
  }
  encounters={}
  thisenc=nil
  lastenc=-1
  lastenclen=0
  needdensity=false
  lastmapid=-1
  i=0;
  while i<lines.length
    line=lines[i]
    FileLineData.setLine(line,linenos[i])
    mapid=line[/^\d+$/]
    if mapid
      lastmapid=mapid
      if thisenc && (thisenc[1][EncounterTypes::Land] ||
                     thisenc[1][EncounterTypes::LandMorning] ||
                     thisenc[1][EncounterTypes::LandDay] ||
                     thisenc[1][EncounterTypes::BugContest] ||
                     thisenc[1][EncounterTypes::LandNight]) &&
                     thisenc[1][EncounterTypes::Cave]
        raise _INTL("Can't define both Land and Cave encounters in the same area (map ID {1})",mapid)
      end
      thisenc=[[25,10,10,0,0,0,0,0,0,25,25,25,25],[]]
      encounters[mapid.to_i]=thisenc
      needdensity=true
      i+=1
      next
    end
    enclines=[12,12,5,5,2,3,5,8,8,12,12,12,12]
    enc=findIndex(EncounterTypes::Names){|val| val==line}
    if enc>=0
      needdensity=false
      encarray=[]
      j=i+1; k=0; 
      while j<lines.length && k<enclines[enc]
        line=lines[j]
        FileLineData.setLine(lines[j],linenos[j])
        splitarr=strsplit(line,/\s*,\s*/)
        if !splitarr || splitarr.length<2
          raise _INTL("In encounters.txt, expected a species entry line,\r\ngot \"{1}\" instead (probably too few entries in an encounter type).\r\nPlease check the format of the section numbered {2},\r\nwhich is just before this line.\r\n{3}",
             line,lastmapid,FileLineData.linereport)
        end
        splitarr[2]=splitarr[1] if splitarr.length==2
        splitarr[1]=splitarr[1].to_i
        splitarr[2]=splitarr[2].to_i
        maxlevel=MAXIMUMLEVEL
        if splitarr[1]<=0 || splitarr[1]>maxlevel
          raise _INTL("Level number is not valid: {1}\r\n{2}",splitarr[1],FileLineData.linereport)
        end
        if splitarr[2]<=0 || splitarr[2]>maxlevel
          raise _INTL("Level number is not valid: {1}\r\n{2}",splitarr[2],FileLineData.linereport)
        end
        if splitarr[1]>splitarr[2]
          raise _INTL("Minimum level is greater than maximum level: {1}\r\n{2}",line,FileLineData.linereport)
        end
        splitarr[0]=parseSpecies(splitarr[0])
        linearr=splitarr
        encarray.push(linearr)
        thisenc[1][enc]=encarray
        j+=1
        k+=1
      end
      if j==lines.length && k<enclines[enc]
         raise _INTL("Reached end of file unexpectedly. There were too few entries in the last section, expected {1} entries.\r\nPlease check the format of the section numbered {2}.\r\n{3}",
            enclines[enc],lastmapid,FileLineData.linereport)
      end
      i=j
    elsif needdensity
      needdensity=false
      nums=strsplit(line,/,/)
      if nums && nums.length>=3
        thisenc[0][EncounterTypes::Land]=nums[0].to_i
        thisenc[0][EncounterTypes::LandMorning]=nums[0].to_i
        thisenc[0][EncounterTypes::LandDay]=nums[0].to_i
        thisenc[0][EncounterTypes::LandNight]=nums[0].to_i
        thisenc[0][EncounterTypes::BugContest]=nums[0].to_i
        thisenc[0][EncounterTypes::Cave]=nums[1].to_i
        thisenc[0][EncounterTypes::Water]=nums[2].to_i

      else
        raise _INTL("Wrong syntax for densities in encounters.txt; got \"{1}\"\r\n{2}",line,FileLineData.linereport)
      end
      i+=1
    else
      raise _INTL("Undefined encounter type {1}, expected one of the following:\r\n{2}\r\n{3}",
         line,EncounterTypes::Names.inspect,FileLineData.linereport)
    end
  end


  enctypeChances=[
    [20,15,12,10,10,10,5,5,5,4,2,2],
    [20,15,12,10,10,10,5,5,5,4,2,2],
    [50,25,15,7,3],
    [50,25,15,7,3],
    [70,30],
    [60,20,20],
    [40,35,15,7,3],
    [30,25,20,10,5,5,4,1],
    [30,25,20,10,5,5,4,1],
    [20,15,12,10,10,10,5,5,5,4,2,2],
    [20,15,12,10,10,10,5,5,5,4,2,2],
    [20,15,12,10,10,10,5,5,5,4,2,2],
    [20,15,12,10,10,10,5,5,5,4,2,2]
  ]
  exporttext = "ENCHASH = {\n"
  encounters.each{|id, map|
    exporttext += "#{id} => { "
    if $cache.mapinfos[i]
      exporttext += "\##{$cache.mapinfos[i].name}"
    end
    exporttext += "\n"
    exporttext += "\t:landrate => #{map[0][0]},\n" if map[0][0] != 0
    exporttext += "\t:caverate => #{map[0][1]},\n" if map[0][1] != 0
    exporttext += "\t:waterrate => #{map[0][2]},\n" if map[0][2] != 0
    encounterdata = map[1]
    for enc in 0...encounterdata.length
      sectiontext = ""
      next if !encounterdata[enc] 
      case enc
        when 0 then exporttext += "\t:Land => {\n"
        when 1 then exporttext += "\t:Cave => {\n"
        when 2 then exporttext += "\t:Water => {\n"
        when 3 then exporttext += "\t:RockSmash => {\n"
        when 4 then exporttext += "\t:OldRod => {\n"
        when 5 then exporttext += "\t:GoodRod => {\n"
        when 6 then exporttext += "\t:SuperRod => {\n"
        when 7 then exporttext += "\t:Headbutt => {\n"
        when 9 then sectiontext = "\t:LandMorning => {\n"
        when 10 then sectiontext = "\t:LandDay => {\n"
        when 11 then sectiontext = "\t:LandNight => {\n"
        when 8 then next
      end
      if [9,10,11].include?(enc) #skip this section if it's no different than the standard land encounters
        next if encounterdata[0] == encounterdata[enc]
        exporttext += sectiontext
      end
      #now get the mons with their weight, species, and level range
      for index in 0...encounterdata[enc].length
        monname = encounterdata[enc][index][0]
        exporttext += "\t\t:#{monname} => [#{enctypeChances[enc][index]},#{encounterdata[enc][index][1]},#{encounterdata[enc][index][2]}]"
        if index != encounterdata[enc].length-1
          exporttext += ","
        end
        exporttext += "\n"
      end
      exporttext += "\t},\n"
    end
    exporttext += "},\n"
  }
  exporttext += "}"
  File.open("Scripts/"+GAMEFOLDER+"/ConvertedDOH/encconverter.rb","w"){|f|
    f.write(exporttext)
  }
  fixEncountersSeveralSameMon
end

def convertCon
  records=[]
  constants=""
  itemnames=[]
  pbCompilerEachPreppedLine("PBS/connections.txt"){|line,lineno|
     hashenum={
        "N"=>"N","North"=>"N",
        "E"=>"E","East"=>"E",
        "S"=>"S","South"=>"S",
        "W"=>"W","West"=>"W"
     }
     record=[]
     thisline=line.dup
     record.push(csvInt!(thisline,lineno))
     record.push(csvEnumFieldOrInt!(thisline,hashenum,"",_INTL("(line {1})",lineno)))
     record.push(csvInt!(thisline,lineno))
     record.push(csvInt!(thisline,lineno))
     record.push(csvEnumFieldOrInt!(thisline,hashenum,"",_INTL("(line {1})",lineno)))
     record.push(csvInt!(thisline,lineno))          
     if !pbRgssExists?(sprintf("Data/Map%03d.rxdata",record[0])) &&
        !pbRgssExists?(sprintf("Data/Map%03d.rvdata",record[0]))
       print _INTL("Warning: Map {1}, as mentioned in the map\r\nconnection data, was not found.\r\n{2}",record[0],FileLineData.linereport)
     end
     if !pbRgssExists?(sprintf("Data/Map%03d.rxdata",record[3])) &&
        !pbRgssExists?(sprintf("Data/Map%03d.rvdata",record[3]))
       print _INTL("Warning: Map {1}, as mentioned in the map\r\nconnection data, was not found.\r\n{2}",record[3],FileLineData.linereport)
     end
     case record[1]
       when "N"
         raise _INTL("North side of first map must connect with south side of second map\r\n{1}",FileLineData.linereport) if record[4]!="S"
       when "S"
         raise _INTL("South side of first map must connect with north side of second map\r\n{1}",FileLineData.linereport) if record[4]!="N"
       when "E"
         raise _INTL("East side of first map must connect with west side of second map\r\n{1}",FileLineData.linereport) if record[4]!="W"
       when "W"
         raise _INTL("West side of first map must connect with east side of second map\r\n{1}",FileLineData.linereport) if record[4]!="E"
     end
     records.push(record)
  }
  
  exporttext = "MAPCONNECTIONSHASH = {\n"
  mapdata = records
  mapdata.each { |connection|
    case connection[1]
    when "N"
      connection[1] = "North"
    when "E"
      connection[1] = "East"
    when "S"
      connection[1] = "South"
    when "W"
      connection[1] = "West"
    end
    case connection[4]
    when "N"
      connection[4] = "North"
    when "E"
      connection[4] = "East"
    when "S"
      connection[4] = "South"
    when "W"
      connection[4] = "West"
    end
    exporttext += "#{connection[0]} => {"
    if $cache.mapinfos[connection[0]]
      exporttext += " \##{$cache.mapinfos[connection[0]].name}"
    end
    exporttext += "\n\t:connections => [#{connection}"
    $cache.map_conns.each { |connection2|
      case connection2[1]
      when "N"
        connection2[1] = "North"
      when "E"
        connection2[1] = "East"
      when "S"
        connection2[1] = "South"
      when "W"
        connection2[1] = "West"
      end
      case connection2[4]
      when "N"
        connection2[4] = "North"
      when "E"
        connection2[4] = "East"
      when "S"
        connection2[4] = "South"
      when "W"
        connection2[4] = "West"
      end
      exporttext += ",\t#{connection2}" if (connection2[0] == connection[0]) && (connection[3] != connection2[3])
    }
    exporttext += "],\n"
    exporttext += "},\n"
  }
  exporttext += "}"
  File.open("Scripts/"+GAMEFOLDER+"/ConvertedDOH/mapconnectionsconverter.rb","w"){|f|
    f.write(exporttext)
  }
end

def convertTeam
  lines=[]
  linenos=[]
  lineno=1
  File.open("PBS/trainers.txt","rb"){|f|
     FileLineData.file="PBS/trainers.txt"
     f.each_line {|line|
        line=prepline(line)
        if line!=""
          lines.push(line)
          linenos.push(lineno)
        end
        lineno+=1
     }
  }
  nameoffset=0
  trainers=[]
  trainernames=[]
  i=0; loop do break unless i<lines.length
    FileLineData.setLine(lines[i],linenos[i])
    trainername=lines[i]
    FileLineData.setLine(lines[i+1],linenos[i+1])
    nameline=strsplit(lines[i+1],/\s*,\s*/)
    name=nameline[0]
    raise _INTL("Trainer name too long\r\n{1}",FileLineData.linereport) if name.length>=0x10000
    trainernames.push(name)
    partyid=0
    if nameline[1]&&nameline[1]!=""
      raise _INTL("Expected a number for the trainer battle ID\r\n{1}",FileLineData.linereport) if !nameline[1][/^\d+$/]
      partyid=nameline[1].to_i
    end
    FileLineData.setLine(lines[i+2],linenos[i+2])
    items=strsplit(lines[i+2],/\s*,\s*/)
    items[0].gsub!(/^\s+/,"")
    raise _INTL("Expected a number for the number of Pokémon\r\n{1}",FileLineData.linereport) if !items[0][/^\d+$/]
    cprint "Converting trainer #{name} #{partyid}                           \r"
    numpoke=items[0].to_i
    realitems=[]
    for j in 1...items.length # Number of Pokémon and items held by Trainer
      realitems.push(items[j].to_sym)
    end
    pkmn=[]
    for j in 0...numpoke
      FileLineData.setLine(lines[i+j+3],linenos[i+j+3])
      poke=strsplit(lines[i+j+3],/\s*,\s*/)
      mon = {}
      delta=0 #non delta
      pokesym = poke[0].to_sym
      poke[0] = pokesym
      mon.store(:species,poke[0])
      mon.store(:level,poke[1].to_i) # Level

      if !poke[2] || poke[2]=="" # item
        #next
      else
        mon.store(:item,poke[2].to_sym)
      end

      strmoves = [poke[3],poke[4],poke[5],poke[6]]
      moves = []
      strmoves.each{|mv| 
        if mv && mv!=""
          moves.push(mv.to_sym)
        end
      }
      mon.store(:moves, moves) if !moves.empty?

      if !poke[7] || poke[7]=="" # Ability
        #next
      else
        if delta == 0
          abillist = $cache.pkmn[poke[0]].Abilities
          abillist += [$cache.pkmn[poke[0]].flags[:HiddenAbilities]] if $cache.pkmn[poke[0]].checkFlag?(:HiddenAbilities)
        end
        if delta == 1
          abillist = $cache.pkmn[poke[0]].formData.dig("Delta Form", :Abilities)
          abillist += [$cache.pkmn[poke[0]].formData.dig("Delta Form", :HiddenAbilities)]
        end
        if delta == 2
          abillist = $cache.pkmn[poke[0]].formData.dig("Delta Form 2", :Abilities)
          abillist += [$cache.pkmn[poke[0]].formData.dig("Delta Form 2", :HiddenAbilities)]
        end
        mon.store(:ability, abillist[poke[7].to_i])
      end
      if !poke[8] || poke[8]=="" # Gender
        #poke[8]=nil
      else
        mon.store(:gender,["M","F"][poke[8].to_i]) 
      end
      if !poke[9] || poke[9]=="" # Form
        #poke[9]=0
      else
        mon.store(:form, poke[9].to_i)
      end
      if !poke[10] || poke[10]==""
        #
      else
        mon.store(:shiny, true) if poke[10].clone == "shiny" # Shiny
      end
      if !poke[11] || poke[11]==""
        #
      else
        mon.store(:nature,poke[11].to_sym)
      end
      mon.store(:iv,31) #IVS
      if !poke[13] || poke[13]=="" # Happiness
        #poke[13]=70
      else
        mon.store(:happiness, poke[13].to_i)
      end
      if !poke[14] || poke[14]=="" # Nickname
        #poke[14]=nil
      else
        mon.store(:name, poke[14].to_s)
      #       raise _INTL("Bad nickname: {1} (must be 1-10 characters)\r\n{2}",poke[14],FileLineData.linereport) if (poke[14].to_s).length>10
      end
      mon.store(:ev,[[85,mon[:level]*3/2].min]*6)
      poke.flatten! #catch any nils
      pkmn.push(mon)
      $stdout.flush
    end
    i+=3+numpoke
    trainers.push([trainername,name,realitems,pkmn,partyid])
    nameoffset+=name.length
  end
  cprint "Converted all trainers.                           \n"

  exporttext = "TEAMARRAY = ["
  for trainer in trainers
    next if trainer.empty?
    cprint "Exporting trainer #{trainer[1]} #{trainer[4]}                             \r"
    exporttext += "{\n"
    exporttext += ":teamid => [\"#{trainer[1]}\",:#{trainer[0]},#{trainer[4]}],\n"
    if !trainer[2].empty?
      exporttext += ":items => ["
      check = 1
      for item in trainer[2]
        exporttext += ":#{item}"
        exporttext += "," if check != trainer[2].length
        check += 1
      end
      exporttext += "],\n"
    end
    exporttext += ":mons => ["
    check = 1
    for mon in trainer[3]
      exporttext += "{\n"
      exporttext += "\t:species => :#{mon[:species]},\n"
      exporttext += "\t:name => \"#{mon[:name].gsub('\\') { '\\\\' }}\",\n" if mon[:name]
      exporttext += "\t:level => #{mon[:level]},\n"
      exporttext += "\t:item => :#{mon[:item]},\n" if mon[:item]
      exporttext += "\t:moves => #{mon[:moves].inspect},\n" if mon[:moves]
      exporttext += "\t:ability => :#{mon[:ability]},\n" if mon[:ability]
      exporttext += "\t:gender => #{mon[:gender].inspect},\n" if mon[:gender]
      exporttext += "\t:form => #{mon[:form]},\n" if mon[:form]
      exporttext += "\t:shiny => true,\n" if mon[:shiny]
      exporttext += "\t:nature => :#{mon[:nature]},\n" if mon[:nature]
      exporttext += "\t:iv => #{mon[:iv]},\n" if mon[:iv]
      exporttext += "\t:ev => #{mon[:ev].inspect},\n" if mon[:ev]
      exporttext += "\t:happiness => #{mon[:happiness]},\n" if mon[:happiness]
      if check != trainer[3].length
        exporttext += "},\n"
      else
        exporttext += "}"
      end
      check += 1
    end
    exporttext += "]},\n"
    $stdout.flush
  end
  exporttext += "]"
  File.open("Scripts/"+GAMEFOLDER+"/ConvertedDOH/trainerconverter.rb","wb"){|f|
    f.write(exporttext)#.force_encoding('UTF-8'))
  }
  cprint "Finished exporting trainers                                   \n"
end

def convertMons(merger=true)
  monhash = {}
  fulllist = ""
  eggroups = [nil,"Monster","Water1","Bug","Flying",
    "Field","Fairy","Grass","HumanLike","Water3",
    "Mineral","Amorphous","Water2",nil,"Dragon","Undiscovered"]
  cprint "Reading PBS/pokemon.txt..."
  File.open("PBS/pokemon.txt","rb"){|f|
    fulllist = f.read()
  }
  list = fulllist.split(/\[[0-9]+\]/)
  cprint "done\n"
  
  for num in 0...list.length
    mon = list[num]
    next if mon == ""
    monsym = nil
    entries = mon.split("\r\n")
    for entry in entries
      data = entry.split("=")
      if data[0] == "InternalName" 
        monsym = data[1]
        monsym = monsym.to_sym
        monhash[monsym] = {}
      end
    end
    next if !monsym

    cprint "Extracting Pokemon data...#{monsym}\r"
    dexdat = monhash[monsym]
    dexdat.store(:dexnum,num)
    for entry in entries
      next if entry == ""
      data = entry.split("=")
      next if data[1] == nil
      case data[0]
        when "Name"
          dexdat.store(:name,data[1])
        when "InternalName"
          next
        when "Type1"
          dexdat.store(:Type1,data[1].to_sym)
        when "Type2"
          dexdat.store(:Type2,data[1].to_sym)
        when "BaseStats"
          stats = data[1].split(",")
          temp = stats[3]
          stats[3] = nil
          stats.flatten!
          stats.push(temp)
          dexdat.store(:BaseStats, stats.map(&:to_i))
        when "GenderRate"
          gender = nil
          case data[1]
            when "Genderless" then gender = :Genderless
            when "AlwaysMale" then gender = :MaleZero
            when "AlwaysFemale" then gender = :FemZero 
            when "FemaleOneEighth" then gender = :FemEighth
            when "Female25Percent" then gender = :FemQuarter
            when "Female50Percent" then gender = :FemHalf
            when "Female75Percent" then gender = :MaleQuarter
          end
          gender = :MaleEighth if monsym == :LITELO || monsym == :PYROAR
          dexdat.store(:GenderRatio, gender)
        when "GrowthRate"
          growth = nil
          case data[1]
            when "Erratic" then growth = :Erratic
            when "Fluctuating" then growth = :Fluctuating
            when "Parabolic" then growth = :MediumSlow
            when "Fast" then growth = :Fast
            when "Medium" then growth = :MediumFast
            when "Slow" then growth = :Slow
          end
          dexdat.store(:GrowthRate, growth)
        when "BaseEXP"
          dexdat.store(:BaseEXP, data[1].to_i)
        when "EffortPoints"
          stats = data[1].split(",")
          temp = stats[3]
          stats[3] = nil
          stats.flatten!
          stats.push(temp)
          dexdat.store(:EVs, stats.map(&:to_i))
        when "Rareness"
          dexdat.store(:CatchRate, data[1].to_i)
        when "Happiness"
          dexdat.store(:Happiness, data[1].to_i)
        when "Abilities"
          dexdat.store(:Abilities, data[1].split(",").map(&:to_sym))
        when "HiddenAbility"
          dexdat.store(:HiddenAbilities, data[1].to_sym)
        when "Moves"
          movesold = data[1].split(",")
          movesnew = []
          j = 0
          for i in 0...movesold.length/2
            j = i*2
            movesnew.push([movesold[j],movesold[j+1].to_sym])
          end
          dexdat.store(:Moveset, movesnew)
        when "Compatibility"
          arr = []
          data[1].split(",").each{|group| arr.push(eggroups[group.to_i])}
          dexdat.store(:EggGroups, arr)
        when "StepsToHatch"
          dexdat.store(:EggSteps, data[1].to_i)
        when "Height"
          dexdat.store(:Height, data[1].to_f*10.to_i)
        when "Weight"
          dexdat.store(:Weight, data[1].to_f*10.to_i)
        when "Color"
          dexdat.store(:Color, data[1])
        when "Habitat"
          dexdat.store(:Habitat, data[1])
        when "Kind"
          dexdat.store(:kind, data[1])
        when "Pokedex"
          dexdat.store(:dexentry, data[1].force_encoding("UTF-8"))
        when "BattlerPlayerY"
          dexdat.store(:BattlerPlayerY, data[1].to_i)
        when "BattlerEnemyY"
          dexdat.store(:BattlerEnemyY, data[1].to_i)
        when "BattlerAltitude"
          dexdat.store(:BattlerAltitude, data[1].to_i)
        when "Evolutions"
          next if !data[1]
          evosold = data[1].split(",")
          evosnew = []
          j=0
          for i in 0...evosold.length/3
            j = i*3
            m = evosold[j]
            m = evosold[j][5..] if evosold[j].include?("DELTA")
            m.chop! if m.end_with?("1") || m.end_with?("2")
            m = m.to_sym
            evosnew.push([m,evosold[j+1].to_sym,evosold[j+2].to_i.to_s == evosold[j+2] ? evosold[j+2].to_i : evosold[j+2]=="" ? 0 : evosold[j+2].to_sym])
          end
          dexdat.store(:evolutions,evosnew)
        when "WildItemCommon"
          dexdat.store(:WildItemCommon, data[1].to_sym)
        when "WildItemUncommon"
          dexdat.store(:WildItemUncommon, data[1].to_sym)
        when "WildItemRare"
          dexdat.store(:WildItemRare, data[1].to_sym)
        when "EggMoves"
          next if data[1] == "" || !data[1]
          dexdat.store(:EggMoves, data[1].split(",").map(&:to_sym))
      end
      dexdat.store(:compatiblemoves,Array.new())
      dexdat.store(:moveexceptions,Array.new())
    end
    $stdout.flush
  end
  cprint "Extracting Pokemon data...done                        \n"
  
  movecompat = convertTMCompat
  cprint "Finished extracting TM/HM Compatibility.              \n"
  movecompat.each{|move, monarr|
    cprint "Storing move #{move} into hash...\r"
    next if PBStuff::UNIVERSALTMS.include?(move)
    monarr.each{|mon|
      monhash[mon][:compatiblemoves].push(move) 
    }
    $stdout.flush
  }
  cprint "Stored TM/HM Compatibility.                   \n"

  
  
  cprint "Reading DOH..."
  File.open("Scripts/"+GAMEFOLDER+"/montext.rb"){|f|
    eval(f.read)
  }
  oldhash = MONHASH
  cprint "done\n"

  pkmn = {}
  monhash.each{|key, pbs|
    cprint "Merging Pokemon data for #{key}               \r"
    doh = oldhash.dig(key)
    if doh
      formname = doh.keys[0]
      doh[formname].merge(pbs) {|key, o, n|
        if o.is_a?(Array) && n.is_a?(Array) && !(key == :BaseStats || key == :EVs)
          o.union(n)
        else
          n
        end
      }
    else
      oldhash[key] = {}
      oldhash[key].store("Normal Form",pbs)
      oldhash[key].store(:OnCreation, Hash.new())
    end
    $stdout.flush
  }
  cprint "Merged Pokemon data                       \n"

  oldhash.each{|mon, data|
    cprint "Compiling Pokemon data for #{mon}             \r"
    pkmn.store(mon, MonData.new(mon,data))
    $stdout.flush
  }
  cprint "Compiled Pokemon data                     \n"

  convertMonsPrint(pkmn)
end

def convertTMCompat

  lineno=1
  havesection=false
  sectionname=nil
  sections={}
  if safeExists?("PBS/tm.txt")
    f=File.open("PBS/tm.txt","rb")
    FileLineData.file="PBS/tm.txt"
    f.each_line {|line|
       if lineno==1 && line[0]==0xEF && line[1]==0xBB && line[2]==0xBF
         line=line[3,line.length-3]
       end
       FileLineData.setLine(line,lineno)
       if !line[/^\#/] && !line[/^\s*$/]
         if line[/^\s*\[\s*(.*)\s*\]\s*$/]
           sectionname=parseMove($~[1]).to_sym
           sections[sectionname]=[]
           havesection=true
         else
           if sectionname==nil
             raise _INTL("Expected a section at the beginning of the file.  This error may also occur if the file was not saved in UTF-8.\n{1}",FileLineData.linereport)
           end
           specieslist=line.sub(/\s+$/,"").split(",")
           for species in specieslist
             next if !species || species==""
             sec=sections[sectionname]
             sec[sec.length]=parseSpecies(species).to_sym
           end
         end
       end
       cprint "Extracting data for move #{sectionname}...\r"
       lineno+=1
       $stdout.flush

    }
    f.close
  end
  return sections
end

def convertMonsPrint(pkmn)
  exporttext = "MONHASH = {\n"
  for i in pkmn.keys
    mon = pkmn[i]
    $stdout.flush
    cprint "Exporting species #{i}             \r"
    #print mon.inspect
    exporttext += ":#{i} => {\n"
    if mon.forms.empty?
        exporttext += "\t\"Normal Form\" => {\n"
        exporttext += getMonOutput(mon)
    else
        for form in 0...mon.forms.length
            formthing = ""
            formname = mon.forms[form]
            formname = "Normal" if formname == "" || !formname
            next if formname.include?("PULSE") || formname.include?("Dev")
            if formname == "Normal" || formname == "Galarian" || formname == "Alolan" || formname == "PULSE" || formname == "Mega" || formname == "Dev" || formname == "Rift" || formname == "Aevian " || i == :MIMIKYU
                formthing += " Form" if i != :ARCEUS && i != :SILVALLY
            end
            exporttext += "\t\"#{mon.forms[form]}#{formthing}\" => {\n"
            if form == 0
                exporttext += getMonOutput(mon) 
                next
            end
            exporttext += "\t\t:name => \"#{mon.formData.dig(mon.forms[form],:name)}\",\n" if mon.formData.dig(mon.forms[form],:name)
            exporttext += "\t\t:dexnum => #{mon.formData.dig(mon.forms[form],:dexnum)},\n" if mon.formData.dig(mon.forms[form],:dexnum)
            exporttext += "\t\t:Type1 => :#{mon.formData.dig(mon.forms[form],:Type1)},\n" if mon.formData.dig(mon.forms[form],:Type1)
            exporttext += "\t\t:Type2 => :#{mon.formData.dig(mon.forms[form],:Type2)},\n" if mon.formData.dig(mon.forms[form],:Type2)
            exporttext += "\t\t:BaseStats => #{mon.formData.dig(mon.forms[form],:BaseStats).inspect},\n" if mon.formData.dig(mon.forms[form],:BaseStats)
            exporttext += "\t\t:EVs => #{mon.formData.dig(mon.forms[form],:EVs).inspect},\n" if mon.formData.dig(mon.forms[form],:EVs)
            exporttext += "\t\t:Abilities => #{mon.formData.dig(mon.forms[form],:Abilities)},\n" if mon.formData.dig(mon.forms[form],:Abilities)
            exporttext += "\t\t:HiddenAbilities => :#{mon.formData.dig(mon.forms[form],:HiddenAbilities)},\n" if mon.formData.dig(mon.forms[form],:HiddenAbilities)
            exporttext += "\t\t:GrowthRate => :#{mon.formData.dig(mon.forms[form],:GrowthRate)},\n" if mon.formData.dig(mon.forms[form],:GrowthRate)
            exporttext += "\t\t:GenderRatio => :#{mon.formData.dig(mon.forms[form],:GenderRatio)},\n" if mon.formData.dig(mon.forms[form],:GenderRatio)
            exporttext += "\t\t:BaseEXP => #{mon.formData.dig(mon.forms[form],:BaseEXP)},\n" if mon.formData.dig(mon.forms[form],:BaseEXP)
            exporttext += "\t\t:CatchRate => #{mon.formData.dig(mon.forms[form],:CatchRate)},\n" if mon.formData.dig(mon.forms[form],:CatchRate)
            exporttext += "\t\t:Happiness => #{mon.formData.dig(mon.forms[form],:Happiness)},\n" if mon.formData.dig(mon.forms[form],:Happiness)
            exporttext += "\t\t:EggSteps => #{mon.formData.dig(mon.forms[form],:EggSteps)},\n" if mon.formData.dig(mon.forms[form],:EggSteps)
            if mon.formData.dig(mon.forms[form],:EggMoves)
              exporttext += "\t\t:EggMoves => ["
              for eggmove in mon.formData.dig(mon.forms[form],:EggMoves)
                exporttext += ":#{eggmove},"
              end
              exporttext += "],\n"
            end
            if mon.formData.dig(mon.forms[form],:preevo)
              exporttext += "\t\t:preevo => {\n"
              exporttext += "\t\t\t:species => :#{mon.formData.dig(mon.forms[form],:preevo)[:species]},\n"
              exporttext += "\t\t\t:form => #{mon.formData.dig(mon.forms[form],:preevo)[:form]}\n"
              exporttext += "\t\t},\n"
            end
            if mon.formData.dig(mon.forms[form],:Moveset)
              exporttext += "\t\t:Moveset => [\n"
              for move in mon.formData.dig(mon.forms[form],:Moveset)
                exporttext += "\t\t\t[#{move[0]},:#{move[1]}]"
                exporttext += ",\n"
              end
              exporttext += "\t\t],\n"
            end
            if mon.formData.dig(mon.forms[form],:compatiblemoves)
                exporttext += "\t\t:compatiblemoves => ["
                for j in mon.formData.dig(mon.forms[form],:compatiblemoves)
                    next if PBStuff::UNIVERSALTMS.include?(j)
                    exporttext += ":#{j},"
                end
                exporttext += "],\n"
            end
            if mon.formData.dig(mon.forms[form],:moveexceptions)
                exporttext += "\t\t:moveexceptions => ["
                for j in mon.formData.dig(mon.forms[form],:moveexceptions)
                    exporttext += ":#{j},"
                end
                exporttext += "],\n"
            end
            if mon.formData.dig(mon.forms[form],:shadowmoves)
              exporttext += "\t\t:shadowmoves => ["
              for shadowmove in mon.formData.dig(mon.forms[form],:shadowmoves)
                exporttext += ":#{shadowmove},"
              end
              exporttext += "],\n"
            end
            exporttext += "\t\t:Color => \"#{mon.formData.dig(mon.forms[form],:Color)}\",\n" if mon.formData.dig(mon.forms[form],:Color)
            exporttext += "\t\t:Habitat => \"#{mon.formData.dig(mon.forms[form],:Habitat)}\",\n" if mon.formData.dig(mon.forms[form],:Habitat)
            exporttext += "\t\t:EggGroups => #{mon.formData.dig(mon.forms[form],:EggGroups)},\n" if mon.formData.dig(mon.forms[form],:EggGroups)
            exporttext += "\t\t:Height => #{mon.formData.dig(mon.forms[form],:Height)},\n" if mon.formData.dig(mon.forms[form],:Height)
            exporttext += "\t\t:Weight => #{mon.formData.dig(mon.forms[form],:Weight)},\n" if mon.formData.dig(mon.forms[form],:Weight)
            exporttext += "\t\t:WildItemCommon => :#{mon.formData.dig(mon.forms[form],:WildItemCommon)},\n" if mon.formData.dig(mon.forms[form],:WildItemCommon)
            exporttext += "\t\t:WildItemUncommon => :#{mon.formData.dig(mon.forms[form],:WildItemUncommon)},\n" if mon.formData.dig(mon.forms[form],:WildItemUncommon)
            exporttext += "\t\t:WildItemRare => :#{mon.formData.dig(mon.forms[form],:WildItemRare)},\n" if mon.formData.dig(mon.forms[form],:WildItemRare)
            exporttext += "\t\t:kind => \"#{mon.formData.dig(mon.forms[form],:kind)}\",\n" if mon.formData.dig(mon.forms[form],:kind)
            exporttext += "\t\t:dexentry => \"#{mon.formData.dig(mon.forms[form],:dexentry)}\",\n" if mon.formData.dig(mon.forms[form],:dexentry)
            exporttext += "\t\t:BattlerPlayerY => #{mon.formData.dig(mon.forms[form],:BattlerPlayerY)},\n" if mon.formData.dig(mon.forms[form],:BattlerPlayerY)
            exporttext += "\t\t:BattlerEnemyY => #{mon.formData.dig(mon.forms[form],:BattlerEnemyY)},\n" if mon.formData.dig(mon.forms[form],:BattlerEnemyY)
            exporttext += "\t\t:BattlerAltitude => #{mon.formData.dig(mon.forms[form],:BattlerAltitude)},\n" if mon.formData.dig(mon.forms[form],:BattlerAltitude)
            if mon.formData.dig(mon.forms[form],:evolutions)
              evos = mon.formData.dig(mon.forms[form],:evolutions)
              check = 1
              exporttext += "\t\t:evolutions => [\n"
              for evo in evos
                exporttext += "\t\t\t[:#{evo[0].to_s},:#{evo[1].to_s}"
                evomethods = ["Item","ItemMale","ItemFemale","TradeItem","DayHoldItem","NightHoldItem"]
                if evomethods.include?(evo[1].to_s)
                  exporttext += ",:#{evo[2].to_s}"
                else
                  exporttext += ",#{evo[2].is_a?(Integer) ? "" : ":"}#{evo[2].to_s}" if evo[2]
                end
                exporttext += "],\n" if check != evos.length
                exporttext += "]\n" if check == evos.length
                check += 1
              end
              exporttext += "\t\t]\n"
            end
            exporttext += "\t},\n\n"
        end
        exporttext += "\t:OnCreation => #{mon.formInit},\n" if mon.formInit
        exporttext += "\t:MegaForm => #{mon.formData.dig(:MegaForm)},\n" if mon.formData.dig(:MegaForm)
        exporttext += "\t:PrimalForm => #{mon.formData.dig(:PrimalForm)},\n" if mon.formData.dig(:PrimalForm)
        exporttext += "\t:DefaultForm => #{mon.formData.dig(:DefaultForm)},\n" if mon.formData.dig(:DefaultForm)
    end
    exporttext += "},\n\n"
    
  end
  exporttext += "}"
  cprint "Successfully dumped Pokemon data        \n"
  File.open("Scripts/"+GAMEFOLDER+"/ConvertedDOH/montextconverter.rb","w"){|f|
    f.write(exporttext)
  }
end

def splitBattleButtons
  longtype = RPG::Cache.load_bitmap("Graphics/Pictures/Battle/battleFightButtons")
  height = 46
  width = longtype.width
  buttons = longtype.height / height #normal size of buttons
  puts "Warning: More buttons (#{buttons}) than types (#{$cache.types.length}) exist on graphic." if buttons > $cache.types.length
  puts "Warning: Less buttons (#{buttons}) than types (#{$cache.types.length}) exist on graphic." if buttons < $cache.types.length

  for i in 0...buttons
    newbmp = Bitmap.new(width, height)
    newbmp.blt(0, 0, longtype, Rect.new(0, i*height, width, height))
    type = i
    if i < $cache.types.length
      type = $cache.types.keys[i]
    end
		newbmp.to_file("Graphics/Pictures/Battle/battleFightButtons#{type}.png")
  end

end

def splitDexTypes
  longtype = RPG::Cache.load_bitmap("Graphics/Pictures/Pokedex/pokedexTypes")
  height = 32
  width = longtype.width
  buttons = longtype.height / height #normal size of buttons
  puts "Warning: More buttons (#{buttons}) than types (#{$cache.types.length}) exist on graphic." if buttons > $cache.types.length
  puts "Warning: Less buttons (#{buttons}) than types (#{$cache.types.length}) exist on graphic." if buttons < $cache.types.length

  for i in 0...buttons
    newbmp = Bitmap.new(width, height)
    newbmp.blt(0, 0, longtype, Rect.new(0, i*height, width, height))
    type = i
    if i < $cache.types.length
      type = $cache.types.keys[i]
      next if !type
    else
      if i == buttons - 1
        type = :FAIRY
      else
        next
      end
    end
		newbmp.to_file("Graphics/Pictures/Pokedex/pokedex#{type}.png")
  end

end