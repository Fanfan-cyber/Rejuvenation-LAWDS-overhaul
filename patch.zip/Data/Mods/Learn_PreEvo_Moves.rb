# For those pesky moves locked in a pre-evolution, this snippet is based from AMB - Misc LearnPreEvolutionMoves.rb:
# From: Jarred aka Matt

# Edited by Pixel / Electronic Witch to work in LAWDs

def pbEachNaturalMove(pokemon)
  puts pokemon
  movelist=pokemon.getMoveList
  for i in movelist
    yield i[1],i[0]
  end
  preevo1 = pbGetPreviousForm(pokemon.species,pokemon.form)
  formname = $cache.pkmn[preevo1[0]].forms[preevo1[1]]
  #Edited by Pixel - Start
  tempPokemon = pokemon.clone
  #Edited by Pixel - End
  if (!preevo1[0].nil? && !preevo1[1].nil?) && formname != "Mega" && formname != "Primal"
    #Edited by Pixel - Start
    if preevo1[1] == 0 || tempPokemon.getMoveList.nil?
      preevo1[1] = 0
      tempPokemon.species = preevo1[0]
      tempPokemon.form = preevo1[1]
      movelist=tempPokemon.getMoveList
    else
      tempPokemon.species = preevo1[0]
      tempPokemon.form = preevo1[1]
      movelist=tempPokemon.getMoveList
    end
    #Edited by Pixel - End
    for i in movelist
      yield i[1],i[0]
    end
  end
  preevo2 = pbGetPreviousForm(preevo1[0],preevo1[1])
  formname = $cache.pkmn[preevo2[0]].forms[preevo2[1]]
  if (!preevo2[0].nil? && !preevo2[1].nil?) && formname != "Mega" && formname != "Primal"
    #Edited by Pixel - Start
    if preevo2[1] == 0 || tempPokemon.getMoveList.nil?
      preevo2[1] = 0
      tempPokemon.species = preevo2[0]
      tempPokemon.form = preevo2[1]
      movelist = tempPokemon.getMoveList
    else
      tempPokemon.species = preevo2[0]
      tempPokemon.form = preevo2[1]
      movelist=tempPokemon.getMoveList
    end
    #Edited by Pixel - Start
    for i in movelist
      yield i[1],i[0]
    end
  end
end
