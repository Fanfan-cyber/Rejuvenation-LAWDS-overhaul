###### MOD ######
class DaycarePC
    def shouldShow?
        return true if $PokemonBag.pbHasItem?(:HM01)
        return false
    end

    def name
        return _INTL("Ring the Daycare")
    end

    def access
        Kernel.pbMessage(_INTL("\\se[accesspc]Hi, sweetie! Do you want me to take care of your Pokémon?"))
        daycarecmd=0
        loop do
            daycarecmds = [
                _INTL("Summary"),
                _INTL("Deposit Pokémon"),
                _INTL("Withdraw Pokémon"),
                _INTL("Wait for Egg"),
                _INTL("Collect Egg"),
                _INTL("Hatch Eggs"),
                _INTL("Nevermind")]
            daycarecmd = Kernel.pbShowCommands(nil,daycarecmds,-1,daycarecmd)
            break if daycarecmd<0
            if daycarecmd == 0 # Summary
                if $PokemonGlobal.daycare
                    num=pbDayCareDeposited
                    Kernel.pbMessage(_INTL("We got {1} Pokémon in the Day Care right now.",num))
                    if num>0
                        txt=""
                        for i in 0...num
                            next if !$PokemonGlobal.daycare[i][0]
                            pkmn=$PokemonGlobal.daycare[i][0]
                            initlevel=$PokemonGlobal.daycare[i][1]
                            gender=[_INTL("♂"),_INTL("♀"),_INTL("genderless")][pkmn.gender]
                            txt+=_INTL("{1}) {2} ({3}), Lv.{4}",
                            i,pkmn.name,gender,pkmn.level)
                            txt+="\n" if i<num-1
                        end
                        Kernel.pbMessage(txt)
                    end
                    if $PokemonGlobal.daycareEgg==1
                    Kernel.pbMessage(_INTL("Ah, we got an egg here!"))
                    elsif pbDayCareDeposited==2
                        if pbDayCareGetCompat==0
                            Kernel.pbMessage(_INTL("They don't seem to like each other much."))
                        else
                            Kernel.pbMessage(_INTL("They seem pretty friendly with each other."))
                        end
                    end
                end
            elsif daycarecmd == 1 # Deposit
                if pbEggGenerated?
                    Kernel.pbMessage(_INTL("You should pick up this egg first!"))
                elsif pbDayCareDeposited==2
                    Kernel.pbMessage(_INTL("You already have two pokemon over here!"))
                elsif $Trainer.party.length==0
                    Kernel.pbMessage(_INTL("That's the last Pokémon in your party!"))
                else
                    pbChooseNonEggPokemon(1,3)
                    if pbGet(1)>=0
                    pbDayCareDeposit(pbGet(1))
                    Kernel.pbMessage(_INTL("We'll take care of {1}.",pbGet(3)))
                    end
                end
            elsif daycarecmd == 2 # Withdraw
                if pbEggGenerated?
                    Kernel.pbMessage(_INTL("You should pick up this egg first!"))
                elsif pbDayCareDeposited==0
                    Kernel.pbMessage(_INTL("There is no Pokémon here to withdraw!"))
                elsif $Trainer.party.length>=6
                    Kernel.pbMessage(_INTL("You have a full party! You should deposit one of your Pokémon first."))
                else
                    pbDayCareChoose(_INTL("Which one do you want back?"),1)
                    if pbGet(1)>=0
                        pbDayCareGetDeposited(pbGet(1),3,4)
                        pbDayCareWithdraw(pbGet(1))
                        Kernel.pbMessage(_INTL("Alrightie, I'll give back {1}.",pbGet(3)))
                    end
                end
            elsif daycarecmd == 3 # Wait for Egg
                if $game_switches[1776] 
                    if $PokemonGlobal.daycareEgg==1
                        Kernel.pbMessage(_INTL("There's an egg here, I don't think another egg will show up..."))
                    elsif pbDayCareDeposited!=2
                        Kernel.pbMessage(_INTL("There aren't 2 Pokémon in the Day Care. I don't think an egg will show up..."))
                    elsif pbDayCareGetCompat==0
                        Kernel.pbMessage(_INTL("The Pokémon don't seem to like each other much."))
                    else
                        $PokemonGlobal.daycareEgg=1
                        Kernel.pbMessage(_INTL("Ah, it looks like an egg showed up!"))
                    end
                else
                    Kernel.pbMessage(_INTL("Ah, it seems you haven't signed up for our EggsHatch+ plan. Please sign up for it!"))
                    Kernel.pbMessage(_INTL("A disembodied voice says: \"Use code: earlyincu for 100% off your plan for a lifetime!\""))
                end
            elsif daycarecmd == 4 # Collect Egg
                if $PokemonGlobal.daycareEgg!=1
                    Kernel.pbMessage(_INTL("We don't see an egg here... Maybe it'll turn up soon!"))
                elsif $Trainer.party.length>=6
                    Kernel.pbMessage(_INTL("You have a full party! You should deposit one of your Pokémon first."))
                else
                    pbDayCareGenerateEgg
                    $PokemonGlobal.daycareEgg=0
                    $PokemonGlobal.daycareEggSteps=0
                    Kernel.pbMessage(_INTL("Here's the egg!"))
                end
            elsif daycarecmd == 5 # Hatch Eggs
                if $game_switches[1776]
                    for pokemon in $Trainer.party
                        pokemon.eggsteps=1 if pokemon.isEgg?
                    end
                    Kernel.pbMessage(_INTL("Any eggs in the party were sped up to hatch!"))
                else
                    Kernel.pbMessage(_INTL("Ah, it seems you haven't signed up for our EggsHatch+ plan. Please sign up for it!"))
                    Kernel.pbMessage(_INTL("A disembodied voice says: \"Use code: earlyincu for 100% off your plan for a lifetime!\""))
                end
            elsif (daycarecmd == 6 || Input.trigger?(Input::B)) # Nevermind
                Kernel.pbMessage(_INTL("Alright sweetie, talk to you soon!"))
                break
            end
        end
    end
end
###### MOD ######
PokemonPCList.registerPC(DaycarePC.new)
###### MOD ######
