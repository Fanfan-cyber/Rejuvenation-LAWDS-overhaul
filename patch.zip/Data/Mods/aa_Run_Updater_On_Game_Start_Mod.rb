# Run Updater On Game Start Mod
# Runs updater.exe when starting the game
# Ensures the game is always up to date
# Requires LAWDS 2.0 at minimum (aka the overhaul)

# Runs updater if last update time is less than 6 hours by default
# Frequency can be customized

# Most of this code is from the Rejuv/LAWDS team. Give them a cookie.
# mod by jmedley

# replace 6 with desired frequency in hours
CHECK_HOURS = 6

MOD_UPDATE = true

# To disable for development purposes ONLY, uncomment the following line:
# MOD_UPDATE = false

if MOD_UPDATE
  time_file = 'last_updated_time.log'
  time_last_updated = nil
  current_time = Time.unrealTime_oldTimeNew
  if safeExists?(time_file)
    File.open(time_file,"rb") {|f|
      time_last_updated = f.mtime
    }
  else
    File.open(time_file,"wb") {|f|
      f.write(current_time)
    }
    File.open(time_file,"rb") {|f|
      time_last_updated = f.mtime
    }
  end
  elapsed = current_time - time_last_updated
  if elapsed >= (3600 * CHECK_HOURS)
    update_status = `updater.exe`
    File.open(time_file,"wb") {|f|
      f.write(current_time)
    }
  end
end

