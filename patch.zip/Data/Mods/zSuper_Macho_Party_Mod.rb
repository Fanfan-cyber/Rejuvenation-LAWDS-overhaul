# Super Macho Party Mod
# Allows LAWDS Macho Brace functions from party screen (outside of battle). 
# Also adds more Macho Brace functions.

# Additional Macho Brace functions:
# - Change mon's shininess
# - Change mon's happiness
# - Change mon's poke ball

# Most of this code is from the Rejuv/LAWDS team. Give them a cookie.
# mod by jmedley

class PokemonScreen
  def pbPokemonScreen
    @scene.pbStartScene(@party,
       @party.length>1 ? _INTL("Choose a Pokémon.") : _INTL("Choose Pokémon or cancel."),nil)
    loop do
      @scene.pbSetHelpText(
         @party.length>1 ? _INTL("Choose a Pokémon.") : _INTL("Choose Pokémon or cancel."))
      pkmnid=@scene.pbChoosePokemon(false,true)
      if pkmnid.is_a?(Array) && pkmnid[0]==1# Switch
        next if pkmnid[1]==6 
        @scene.pbSetHelpText(_INTL("Move to where?"))
        oldpkmnid = pkmnid[1]
        pkmnid = @scene.pbChoosePokemon(true,true,1)
        if pkmnid>=0 && pkmnid!=oldpkmnid && pkmnid<6
          pbSwitch(oldpkmnid,pkmnid)
        end
        next
      end
      if (pkmnid.is_a?(Array))
        break if pkmnid.length<0
      else
        break if pkmnid<0
      end
      pkmn=@party[pkmnid]
      commands=[]
      cmdSummary=-1
      cmdRelearn=-1
      cmdSwitch=-1
      cmdItem=-1
      cmdDebug=-1
      cmdMail=-1
      cmdRename=-1
      # Build the commands
      commands[cmdSummary=commands.length]=_INTL("Summary")
      commands[cmdRelearn=commands.length]=_INTL("Relearn")  # lawds always relearn
      commands[cmdDebug=commands.length]=_INTL("Macho Brace")
      if $game_switches[:EasyHMs_Password]
        acmdTMX=-1
        commands[acmdTMX=commands.length]=_INTL("Use TMX")
      end
      cmdMoves=[-1,-1,-1,-1]
      for i in 0...pkmn.moves.length
        move=pkmn.moves[i]
        # Check for hidden moves and add any that were found
        if !pkmn.isEgg? && (
           (move.move == :MILKDRINK) ||
           (move.move == :SOFTBOILED) ||
           HiddenMoveHandlers.hasHandler(move.move)
           )
          commands[cmdMoves[i]=commands.length]=getMoveName(move.move)
        end
      end
      commands[cmdSwitch=commands.length]=_INTL("Switch") if @party.length>1
      if !pkmn.isEgg?
        if pkmn.mail
          commands[cmdMail=commands.length]=_INTL("Mail")
        else
          commands[cmdItem=commands.length]=_INTL("Item")
        end
        commands[cmdRename = commands.length] = _INTL("Rename")
      end
      commands[commands.length]=_INTL("Cancel")
      command=@scene.pbShowCommands(_INTL("Do what with {1}?",pkmn.name),commands)
      havecommand=false
      for i in 0...4
        if cmdMoves[i]>=0 && command==cmdMoves[i]
          havecommand=true
          if pkmn.moves[i].move == :SOFTBOILED || pkmn.moves[i].move == :MILKDRINK
            if pkmn.hp<=(pkmn.totalhp/5.0).floor
              pbDisplay(_INTL("Not enough HP..."))
              break
            end
            @scene.pbSetHelpText(_INTL("Use on which Pokémon?"))
            oldpkmnid=pkmnid
            loop do
              @scene.pbPreSelect(oldpkmnid)
              pkmnid=@scene.pbChoosePokemon(true)
              break if pkmnid<0
              newpkmn=@party[pkmnid]
              if newpkmn.isEgg? || newpkmn.hp==0 || newpkmn.hp==newpkmn.totalhp || pkmnid==oldpkmnid
                pbDisplay(_INTL("This item can't be used on that Pokémon."))
              else
                pkmn.hp-=(pkmn.totalhp/5.0).floor
                hpgain=pbItemRestoreHP(newpkmn,(pkmn.totalhp/5.0).floor)
                @scene.pbDisplay(_INTL("{1}'s HP was restored by {2} points.",newpkmn.name,hpgain))
                pbRefresh
              end
            end
            break
          elsif Kernel.pbCanUseHiddenMove?(pkmn,pkmn.moves[i].move)
            @scene.pbEndScene
            if pkmn.moves[i].move == :FLY
              if $cache.mapdata[$game_map.map_id].MapPosition.is_a?(Hash)
                region = pbUnpackMapHash[0]
              else
                region=$cache.mapdata[$game_map.map_id].MapPosition[0]
              end              
              scene=PokemonRegionMapScene.new(region,false)
              screen=PokemonRegionMap.new(scene)
              ret=screen.pbStartFlyScreen
              if ret
                $PokemonTemp.flydata=ret
                $game_system.bgs_stop
                $game_screen.weather(0,0,0)
                return [pkmn,pkmn.moves[i].move]
              end
              @scene.pbStartScene(@party,
                 @party.length>1 ? _INTL("Choose a Pokémon.") : _INTL("Choose Pokémon or cancel."))
              break
            end
            return [pkmn,pkmn.moves[i].move]
          else
            break
          end
        end
      end
      if $game_switches[:EasyHMs_Password] && !pkmn.isEgg?
        if acmdTMX>=0 && command==acmdTMX
          aRetArr = passwordUseTMX(pkmn)
          if aRetArr.length > 0
            havecommand=true
            return aRetArr
          end
        end
      end
      next if havecommand
      if cmdSummary>=0 && command==cmdSummary
        @scene.pbSummary(pkmnid)
      elsif cmdRelearn>=0 && command==cmdRelearn
	if pbHasRelearnableMove?(pkmn)
             pbRelearnMoveScreen(pkmn)
	else
	     pbDisplay(_INTL("{1} has no moves it can relearn.",pkmn.name))
	end
      elsif cmdSwitch>=0 && command==cmdSwitch
        @scene.pbSetHelpText(_INTL("Move to where?"))
        oldpkmnid=pkmnid
        pkmnid=@scene.pbChoosePokemon(true)
        if pkmnid>=0 && pkmnid!=oldpkmnid
          pbSwitch(oldpkmnid,pkmnid)
        end
      elsif cmdDebug>=0 && command==cmdDebug
        ItemHandlers.triggerUseOnPokemon(:MACHOBRACE,pkmn,@scene)
      elsif cmdMail>=0 && command==cmdMail
        command=@scene.pbShowCommands(_INTL("Do what with the mail?"),[_INTL("Read"),_INTL("Take"),_INTL("Cancel")])
        case command
          when 0 # Read
            pbFadeOutIn(99999){
               pbDisplayMail(pkmn.mail,pkmn)
            }
          when 1 # Take
            pbTakeItem(pkmn)
            pbRefreshSingle(pkmnid)
        end
      elsif cmdItem>=0 && command==cmdItem
        if $game_variables[650] > 0 
          pbDisplay(_INTL("You are not allowed to change the rental team's items."))
          @scene.pbEndScene
          return nil
        end
        command=@scene.pbShowCommands(_INTL("Do what with an item?"),[_INTL("Use"),_INTL("Give"),_INTL("Take"),_INTL("Cancel")])
        case command
          when 0 # Use
          item=@scene.pbChooseItem($PokemonBag,from_bag: true)
          if !item.nil?
            pbUseItemOnPokemon(item,pkmn,self)
            pbRefreshSingle(pkmnid)
          end            
          when 1 # Give
            item=@scene.pbChooseItem($PokemonBag,from_bag: true)
            if !item.nil?
              if pbIsZCrystal?(item)
                pbUseItemOnPokemon(item,pkmn,self)
              else
                pbGiveItem(item,pkmn,pkmnid)
              end
              pbRefreshSingle(pkmnid)
            end
          when 2 # Take
            pbTakeItem(pkmn)
            pbRefreshSingle(pkmnid)
        end
      elsif cmdRename>=0 && command==cmdRename
        species=getMonName(pkmn.species)
        $game_variables[5]=Kernel.pbMessageFreeText("#{species}'s nickname?",_INTL(""),false,12)
        if pbGet(5)==""
          pkmn.name=getMonName(pkmn.species)
          pbSet(5,pkmn.name)
        end
        pkmn.name=pbGet(5)
        pbDisplay(_INTL("{1} was renamed to {2}.",species,pkmn.name))
      end
    end
    @scene.pbEndScene
    return nil
  end
end

ItemHandlers::UseOnPokemon.add(:MACHOBRACE, proc {|item,pkmn,scene| # LAWDS - macho brace key item
  stats=STATSTRINGS
  cmd=0
  loop do
    if $game_variables[:DifficultyModes]==2
      cmd=scene.pbShowCommands(_INTL("What stats would you like to set?"),[
        _INTL("Set Ability"),
        _INTL("Set EVs"),
        _INTL("Set Nature"),
        _INTL("Set Hidden Power"),
        _INTL("Set Shininess"),
        _INTL("Set Happiness"),
        _INTL("Set Poké Ball")],cmd)
      cmd +=1 if cmd > 1
    else
      cmd=scene.pbShowCommands(_INTL("What stats would you like to set?"),[
        _INTL("Set Ability"),
        _INTL("Set EVs"),
        _INTL("Set IVs"),
        _INTL("Set Nature"),
        _INTL("Set Hidden Power"),
        _INTL("Set Shininess"),
        _INTL("Set Happiness"),
        _INTL("Set Poké Ball")],cmd)
    end
    case cmd
      # Break
      when -1
        break
      # Set Ability
      when 0
        cmd2=0
        loop do
          if pkmn.PULSE3==true
	          if $game_switches[:LAWDS_Pulse3Me]
		          commands=[]
              commands.push("Disable Pulse-3")
              msg=_INTL("Pulse-3 is active.")
              cmd2=scene.pbShowCommands(msg,commands,cmd2)
              if cmd2==0
                pkmn.PULSE3=false
                pkmn.ability=pkmn.getAbilityList[0]
              else
                break
              end
	          else
              pbDisplay(_INTL("Pulse-3 is active. Ability cannot be set."))
              break
            end
          else
          abils=pkmn.getAbilityList
          cmd2 = abils.find_index { |abil| pkmn.ability==abil }
          cmd2 = 0 if cmd2.nil?
          commands=[]
          for i in 0..abils.length-1
            commands.push(getAbilityName(abils[i]))
          end
          commands.push("Enable Pulse-3") if $game_switches[:LAWDS_Pulse3Me] && $Trainer.numbadges >= (2*pkmn.pulseTier - 1) && pkmn.pulseTier >= 0
          msg=_INTL("Current Ability is {1}.",getAbilityName(pkmn.ability))
          cmd2=scene.pbShowCommands(msg,commands,cmd2)
          # Break
          if cmd2==-1
            break
          # Set ability override
          elsif cmd2>=0 && cmd2<abils.length
            pkmn.setAbility(abils[cmd2])
          elsif cmd2>=abils.length
            pkmn.enablePULSE3
            cmd2=0
          end
          end
          scene.pbHardRefresh
        end
      # Set EVs
      when 1
        cmd2=0
        loop do
          if pkmn.isShadow?
            scene.pbDisplay(_INTL("Shadow Pokemon cannot gain EVs."))
            break
          end
          evcommands=[]
          evs = pkmn.ev
          statnums = [pkmn.totalhp, pkmn.attack, pkmn.defense, pkmn.spatk, pkmn.spdef, pkmn.speed]
          if $game_variables[:DifficultyModes]==2
            stats = ["HP", "Offense", "Defense", "Sp. Defense", "Speed"]
            evs = [evs[0],evs[1],evs[2],evs[4],evs[5]]
          end
          for i in 0...stats.length
            evcommands.push(stats[i]+" (#{evs[i]})")            
          end
          evcommands.push("Zero all")
          promptString = _INTL("HP:                  {1} \nAttack:      {2}\nDefense:   {3}\nSp.Atk:       {4}\nSp.Def:       {5} \nSpeed:        {6}", statnums[0],statnums[1],statnums[2],statnums[3],statnums[4],statnums[5])
          cmd2=scene.pbShowCommands(promptString,evcommands,cmd2)
          if cmd2==-1
            break
          elsif cmd2>=0 && cmd2<stats.length
            statindex = $game_variables[:DifficultyModes]==2 && cmd2 > 2 ? cmd2+1 : cmd2
            cmd3 = scene.pbShowCommands(_INTL("Do what to the EV?"),["Set to max", "Set to zero", "Set manually"])
            case cmd3
              when -1
                break
              when 0
                if $game_switches[:No_Total_EV_Cap]
                  pkmn.ev[statindex]=252
                else
                  evsLeft = 510 - pkmn.ev.sum
                  evsLeft = evsLeft + pkmn.ev[3] if $game_variables[:DifficultyModes]==2
                  newEV = [252,pkmn.ev[statindex]+evsLeft].min
                  pkmn.ev[statindex]=newEV
                end
              when 1
                pkmn.ev[statindex]=0
              when 2
                params=ChooseNumberParams.new
                params.setRange(0,252)
                params.setDefaultValue(pkmn.ev[statindex])
                params.setCancelValue(pkmn.ev[statindex])
                f=Kernel.pbMessageChooseNumber(_INTL("Set the EV for {1} (max. 252).",stats[statindex]),params) { scene.pbHardRefresh }
                pkmn.ev[statindex]=f
              end
              pkmn.ev[3] = pkmn.ev[1] if $game_variables[:DifficultyModes]==2
          elsif cmd2==stats.length
            pkmn.ev=[0,0,0,0,0,0]
          end
          #LAWDS - Do sanity checking on EVs
          evTotal = 0
          gone_over = false
          if !$game_switches[:No_Total_EV_Cap]
            for i in 0..5
              next if $game_variables[:DifficultyModes]==2 && i==3
              evTotal += pkmn.ev[i]
              if evTotal > 510 && gone_over == false
                amt_over = evTotal - 510
                pkmn.ev[i] = pkmn.ev[i] - amt_over
                gone_over = true
              elsif gone_over == true
                pkmn.ev[i] = 0
              end
            end
          end
          pkmn.totalhp
          pkmn.calcStats
          scene.pbHardRefresh
        end
      # Set IVs
      when 2
        if $game_variables[:DifficultyModes]==2
          scene.pbDisplay(_INTL("IVs are forced to 31 in Awesome Mode."))
          break
        end
        cmd2=0
        loop do
          hiddenpower=pbHiddenPower(pkmn)
          msg=_INTL("Hidden Power:\n{1}",getTypeName(hiddenpower))
          ivcommands=[]
          for i in 0...stats.length
            ivcommands.push(stats[i]+" (#{pkmn.iv[i]})")
          end
          ivcommands.push(_INTL("Randomise all"))
          cmd2=scene.pbShowCommands(msg,ivcommands,cmd2)
          if cmd2==-1
            break
          elsif cmd2>=0 && cmd2<stats.length
            params=ChooseNumberParams.new
            params.setRange(0,31)
            params.setDefaultValue(pkmn.iv[cmd2])
            params.setCancelValue(pkmn.iv[cmd2])
            f=Kernel.pbMessageChooseNumber(
              _INTL("Set the IV for {1} (max. 31).",stats[cmd2]),params) { scene.pbHardRefresh }
            pkmn.iv[cmd2]=f
            pkmn.calcStats
            scene.pbHardRefresh
          elsif cmd2==ivcommands.length-1
            pkmn.iv[0]=rand(32)
            pkmn.iv[1]=rand(32)
            pkmn.iv[2]=rand(32)
            pkmn.iv[3]=rand(32)
            pkmn.iv[4]=rand(32)
            pkmn.iv[5]=rand(32)
            pkmn.calcStats
            scene.pbHardRefresh
          end
        end
      when 3 # Nature
        cmd-=1 if $game_variables[:DifficultyModes]==2
        cmd2=0
        loop do
          oldnature=pkmn.nature
          commands=[]
          (PBNatures.getCount).times do |i|
            commands.push(PBNatures.getNameAndStatString(i))
          end
          msg=[_INTL("Current Nature is {1}.",oldnature),
               _INTL("Current Nature is {1}.",oldnature)][pkmn.natureflag ? 1 : 0]
          cmd2=scene.pbShowCommands(msg,commands,cmd2)
          # Break
          if cmd2==-1
            break
          # Set nature override
          elsif cmd2>=0 && cmd<PBNatures.getCount
            pkmn.setNature(PBNatures.getName(cmd2).intern.upcase)
            pkmn.calcStats
          end
          scene.pbHardRefresh
        end
      # Hidden Power
      when 4
        cmd-=1 if $game_variables[:DifficultyModes]==2
        HiddenPowerChanger(pkmn)
      when 5
        cmd-=1 if $game_variables[:DifficultyModes]==2
        cmd5=0
        loop do
          msg=[_INTL("Pokemon is shiny."),
               _INTL("Pokemon is normal.")][pkmn.isShiny? ? 0 : 1]
          cmd5=scene.pbShowCommands(msg,[
               _INTL("Make shiny"),
               _INTL("Make normal")],cmd5)
          # Break
          if cmd5==-1
            break
          # Make shiny
          elsif cmd5==0
            pkmn.makeShiny
          # Make normal
          elsif cmd5==1
            pkmn.makeNotShiny
          # Remove override
          end
          scene.pbHardRefresh
        end
      when 6
        cmd-=1 if $game_variables[:DifficultyModes]==2
        params=ChooseNumberParams.new
        params.setRange(0,255)
        params.setDefaultValue(pkmn.happiness)
        h=Kernel.pbMessageChooseNumber(
           _INTL("Set the Pokémon's happiness (max. 255)."),params) { scene.update }
        if h!=pkmn.happiness
          pkmn.happiness=h
          scene.pbDisplay(_INTL("{1}'s happiness was set to {2}.",pkmn.name,pkmn.happiness))
          scene.pbHardRefresh
        end
      when 7
        cmd-=1 if $game_variables[:DifficultyModes]==2
        cmd6=0
        loop do
          oldball=getItemName(pkmn.ballused)
          commands=[]; balls=[]
          for item in $cache.items.keys
            if $cache.items[item].checkFlag?(:ball)
              balls.push([item,getItemName(item)])
            end
          end
          balls.sort! {|a,b| a[1]<=>b[1]}
          for i in 0...commands.length
            cmd6=i if pkmn.ballused==balls[i][0]
          end
          for i in balls
            commands.push(i[1])
          end
          cmd6=scene.pbShowCommands(_INTL("{1} used.",oldball),commands,cmd6)
          if cmd6==-1
            break
          else
            pkmn.ballused=balls[cmd6][0]
          end
        end # loop
      end # case
  end # loop
})

ItemHandlers::UseInField.add(:MACHOBRACE, proc {|item,scene| # LAWDS - macho brace from field
pbFadeOutIn(99999){
  scene=PokemonScreen_Scene.new
  screen=PokemonScreen.new(scene,$Trainer.party)
  screen.pbStartScene(_INTL("Use on which Pokémon?"),false)
  loop do
    scene.pbSetHelpText(_INTL("Use on which Pokémon?"))
    chosen=screen.pbChoosePokemon
    if chosen>=0
      pkmn=$Trainer.party[chosen]
      stats=STATSTRINGS
      cmd=0
      loop do
        if $game_variables[:DifficultyModes]==2
          cmd=scene.pbShowCommands(_INTL("What stats would you like to set?"),[
            _INTL("Set Ability"),
            _INTL("Set EVs"),
            _INTL("Set Nature"),
            _INTL("Set Hidden Power"),
            _INTL("Set Gender"),
            _INTL("Set Shininess"),
            _INTL("Set Happiness"),
            _INTL("Set Poké Ball")],cmd)
          cmd +=1 if cmd > 1
        else
          cmd=scene.pbShowCommands(_INTL("What stats would you like to set?"),[
            _INTL("Set Ability"),
            _INTL("Set EVs"),
            _INTL("Set IVs"),
            _INTL("Set Nature"),
            _INTL("Set Hidden Power"),
            _INTL("Set Gender"),
            _INTL("Set Shininess"),
            _INTL("Set Happiness"),
            _INTL("Set Poké Ball")],cmd)
        end
        case cmd
          # Break
          when -1
            break
          # Set Ability
          when 0
            cmd2=0
            loop do
              if pkmn.PULSE3==true
                commands=[]
                commands.push("Disable Pulse-3")
                msg=_INTL("Pulse-3 is active.")
                cmd2=scene.pbShowCommands(msg,commands,cmd2)
                if cmd2==0
                  pkmn.PULSE3=false
                  pkmn.ability=pkmn.getAbilityList[0]
                else
                  break
                end
              else
              abils=pkmn.getAbilityList
              cmd2 = abils.find_index { |abil| pkmn.ability==abil }
              cmd2 = 0 if cmd2.nil?
              commands=[]
              for i in 0..abils.length-1
                commands.push(getAbilityName(abils[i]))
              end
              commands.push("Enable Pulse-3") if $game_switches[:LAWDS_Pulse3Me]
              msg=_INTL("Current Ability is {1}.",getAbilityName(pkmn.ability))
              cmd2=scene.pbShowCommands(msg,commands,cmd2)
              # Break
              if cmd2==-1
                break
              # Set ability override
              elsif cmd2>=0 && cmd2<abils.length
                pkmn.setAbility(abils[cmd2])
              elsif cmd2>=abils.length
                pkmn.enablePULSE3
                cmd2=0
              end
              end
              scene.pbHardRefresh
            end
           # Set EVs
          when 1
            cmd2=0
            loop do
              if pkmn.isShadow?
                scene.pbDisplay(_INTL("Shadow Pokemon cannot gain EVs."))
                break
              end
              evcommands=[]
              evs = pkmn.ev
              statnums = [pkmn.totalhp, pkmn.attack, pkmn.defense, pkmn.spatk, pkmn.spdef, pkmn.speed]
              if $game_variables[:DifficultyModes]==2
                stats = ["HP", "Offense", "Defense", "Sp. Defense", "Speed"]
                evs = [evs[0],evs[1],evs[2],evs[4],evs[5]]
              end
              for i in 0...stats.length
                evcommands.push(stats[i]+" (#{evs[i]})")            
              end
              evcommands.push("Zero all")
              promptString = _INTL("HP:                  {1} \nAttack:      {2}\nDefense:   {3}\nSp.Atk:       {4}\nSp.Def:       {5} \nSpeed:        {6}", statnums[0],statnums[1],statnums[2],statnums[3],statnums[4],statnums[5])
              cmd2=scene.pbShowCommands(promptString,evcommands,cmd2)
              if cmd2==-1
                break
              elsif cmd2>=0 && cmd2<stats.length
                statindex = $game_variables[:DifficultyModes]==2 && cmd2 > 2 ? cmd2+1 : cmd2
                cmd3 = scene.pbShowCommands(_INTL("Do what to the EV?"),["Set to max", "Set to zero", "Set manually"])
                case cmd3
                when -1
                  break
                when 0
                  if $game_switches[:No_Total_EV_Cap]
                    pkmn.ev[statindex]=252
                  else
                    evsLeft = 510 - pkmn.ev.sum
                    evsLeft = evsLeft + pkmn.ev[3] if $game_variables[:DifficultyModes]==2
                    newEV = [252,pkmn.ev[statindex]+evsLeft].min
                    pkmn.ev[statindex]=newEV
                  end
                when 1
                  pkmn.ev[statindex]=0
                when 2
                  params=ChooseNumberParams.new
                  params.setRange(0,252)
                  params.setDefaultValue(pkmn.ev[statindex])
                  params.setCancelValue(pkmn.ev[statindex])
                  f=Kernel.pbMessageChooseNumber(_INTL("Set the EV for {1} (max. 252).",stats[statindex]),params) { scene.pbHardRefresh }
                  pkmn.ev[statindex]=f
                end
                pkmn.ev[3] = pkmn.ev[1] if $game_variables[:DifficultyModes]==2
              elsif cmd2==stats.length
                pkmn.ev=[0,0,0,0,0,0]
              end
              #LAWDS - Do sanity checking on EVs
              evTotal = 0
              gone_over = false
              if !$game_switches[:No_Total_EV_Cap]
                for i in 0..5
                  next if $game_variables[:DifficultyModes]==2 && i==3
                  evTotal += pkmn.ev[i]
                  if evTotal > 510 && gone_over == false
                    amt_over = evTotal - 510
                    pkmn.ev[i] = pkmn.ev[i] - amt_over
                    gone_over = true
                  elsif gone_over == true
                    pkmn.ev[i] = 0
                  end
                end
              end
              pkmn.totalhp
              pkmn.calcStats
              scene.pbHardRefresh
            end
          # Set IVs
          when 2
            if $game_variables[:DifficultyModes]==2
              scene.pbDisplay(_INTL("IVs are forced to 31 in Awesome Mode."))
              break
            end
            cmd2=0
            loop do
              hiddenpower=pbHiddenPower(pkmn)
              msg=_INTL("Hidden Power:\n{1}",getTypeName(hiddenpower))
              ivcommands=[]
              for i in 0...stats.length
                ivcommands.push(stats[i]+" (#{pkmn.iv[i]})")
              end
              ivcommands.push(_INTL("Randomise all"))
              cmd2=scene.pbShowCommands(msg,ivcommands,cmd2)
              if cmd2==-1
                break
              elsif cmd2>=0 && cmd2<stats.length
                params=ChooseNumberParams.new
                params.setRange(0,31)
                params.setDefaultValue(pkmn.iv[cmd2])
                params.setCancelValue(pkmn.iv[cmd2])
                f=Kernel.pbMessageChooseNumber(
                  _INTL("Set the IV for {1} (max. 31).",stats[cmd2]),params) { scene.pbHardRefresh }
                pkmn.iv[cmd2]=f
                pkmn.calcStats
                scene.pbHardRefresh
              elsif cmd2==ivcommands.length-1
                pkmn.iv[0]=rand(32)
                pkmn.iv[1]=rand(32)
                pkmn.iv[2]=rand(32)
                pkmn.iv[3]=rand(32)
                pkmn.iv[4]=rand(32)
                pkmn.iv[5]=rand(32)
                pkmn.calcStats
                scene.pbHardRefresh
              end
            end
          when 3 # Nature
            cmd-=1 if $game_variables[:DifficultyModes]==2
            cmd2=0
            loop do
              oldnature=pkmn.nature
              commands=[]
              (PBNatures.getCount).times do |i|
                commands.push(PBNatures.getNameAndStatString(i))
              end
              msg=[_INTL("Current Nature is {1}.",oldnature),
                   _INTL("Current Nature is {1}.",oldnature)][pkmn.natureflag ? 1 : 0]
              cmd2=scene.pbShowCommands(msg,commands,cmd2)
              # Break
              if cmd2==-1
                break
              # Set nature override
              elsif cmd2>=0 && cmd<PBNatures.getCount
                pkmn.setNature(PBNatures.getName(cmd2).intern.upcase)
                pkmn.calcStats
              end
              scene.pbHardRefresh
            end
          when 4 # Hidden Power
            cmd-=1 if $game_variables[:DifficultyModes]==2
            HiddenPowerChanger(pkmn)
          when 5
            cmd-=1 if $game_variables[:DifficultyModes]==2
            if pkmn.gender==2
              scene.pbDisplay(_INTL("{1} is genderless.",pkmn.name))
            else
              cmd4=0
              loop do
                oldgender=(pkmn.isMale?) ? _INTL("male") : _INTL("female")
                msg=[_INTL("Gender {1} is natural.",oldgender),
                     _INTL("Gender {1} is being forced.",oldgender)][pkmn.genderflag ? 1 : 0]
                cmd4=scene.pbShowCommands(msg,[
                   _INTL("Make male"),
                   _INTL("Make female"),
                   _INTL("Remove override")],cmd4)
                # Break
                if cmd4==-1
                  break
                # Make male
                elsif cmd4==0
                  pkmn.setGender(0)
                  if pkmn.isMale?
                    scene.pbDisplay(_INTL("{1} is now male.",pkmn.name))
                  else
                    scene.pbDisplay(_INTL("{1}'s gender couldn't be changed.",pkmn.name))
                  end
                # Make female
                elsif cmd4==1
                  pkmn.setGender(1)
                  if pkmn.isFemale?
                    scene.pbDisplay(_INTL("{1} is now female.",pkmn.name))
                  else
                    scene.pbDisplay(_INTL("{1}'s gender couldn't be changed.",pkmn.name))
                  end
                # Remove override
                elsif cmd4==2
                  pkmn.genderflag=nil
                  scene.pbDisplay(_INTL("Gender override removed."))
                end
                $Trainer.pokedex.setFormSeen(pkmn)
                scene.pbHardRefresh
              end
            end
          when 6
            cmd-=1 if $game_variables[:DifficultyModes]==2
            cmd5=0
            loop do
              oldshiny=(pkmn.isShiny?) ? _INTL("shiny") : _INTL("normal")
              msg=[_INTL("Shininess ({1}) is natural.",oldshiny),
                   _INTL("Shininess ({1}) is being forced.",oldshiny)][pkmn.shinyflag!=nil ? 1 : 0]
              cmd5=scene.pbShowCommands(msg,[
                   _INTL("Make shiny"),
                   _INTL("Make normal"),
                   _INTL("Remove override")],cmd5)
              # Break
              if cmd5==-1
                break
              # Make shiny
              elsif cmd5==0
                pkmn.makeShiny
              # Make normal
              elsif cmd5==1
                pkmn.makeNotShiny
              # Remove override
              elsif cmd5==2
                pkmn.shinyflag=nil
              end
              scene.pbHardRefresh
            end
          when 7
            cmd-=1 if $game_variables[:DifficultyModes]==2
            params=ChooseNumberParams.new
            params.setRange(0,255)
            params.setDefaultValue(pkmn.happiness)
            h=Kernel.pbMessageChooseNumber(
               _INTL("Set the Pokémon's happiness (max. 255)."),params) { scene.update }
            if h!=pkmn.happiness
              pkmn.happiness=h
              scene.pbDisplay(_INTL("{1}'s happiness was set to {2}.",pkmn.name,pkmn.happiness))
              scene.pbHardRefresh
            end
          when 8
            cmd-=1 if $game_variables[:DifficultyModes]==2
            cmd6=0
            loop do
              oldball=getItemName(pkmn.ballused)
              commands=[]; balls=[]
              for item in $cache.items.keys
                if $cache.items[item].checkFlag?(:ball)
                  balls.push([item,getItemName(item)])
                end
              end
              balls.sort! {|a,b| a[1]<=>b[1]}
              for i in 0...commands.length
                cmd6=i if pkmn.ballused==balls[i][0]
              end
              for i in balls
                commands.push(i[1])
              end
              cmd6=scene.pbShowCommands(_INTL("{1} used.",oldball),commands,cmd6)
              if cmd6==-1
                scene.pbHardRefresh
                break
              else
                pkmn.ballused=balls[cmd6][0]
              end
            end # loop
        end # case
      end # loop
    else
      ret=false
      break
    end
  end #loop
  screen.pbEndScene
}
})